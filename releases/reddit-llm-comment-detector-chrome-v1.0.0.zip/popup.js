/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
/*!**********************!*\
  !*** ./src/popup.js ***!
  \**********************/
__webpack_require__.r(__webpack_exports__);
// popup.js - Settings and controls for the Reddit AI Comment Detector extension

// Configuration storage key
const SETTINGS_KEY = 'reddit-ai-detector-settings';

// Default settings
const DEFAULT_SETTINGS = {
    showProgress: true,
    showUserScores: true,
    highlightComments: true,
    showHumanIndicators: false,
    autoAnalyze: true,
    aggressionLevel: 'low',
    selectedModel: 'trentmkelly/slop-detector-mini-2'
};

// Load settings from storage
function loadSettings() {
    try {
        return new Promise((resolve) => {
            chrome.storage.local.get([SETTINGS_KEY], (result) => {
                const stored = result[SETTINGS_KEY];
                const finalSettings = stored ? { ...DEFAULT_SETTINGS, ...stored } : DEFAULT_SETTINGS;
                console.log('Popup settings loaded:', finalSettings);
                resolve(finalSettings);
            });
        });
    } catch (error) {
        console.error('Failed to load settings:', error);
        return Promise.resolve(DEFAULT_SETTINGS);
    }
}

// Save settings to storage
function saveSettings(settings) {
    try {
        chrome.storage.local.set({ [SETTINGS_KEY]: settings }, () => {
            console.log('Settings saved:', settings);
        });
    } catch (error) {
        console.error('Failed to save settings:', error);
    }
}

// Demo functionality
let demoTimeout = null;

function classifyDemoText(text) {
    const resultDiv = document.getElementById('demoResult');
    
    if (!text || text.trim().length < 10) {
        resultDiv.textContent = text.trim().length === 0 ? '' : 'Enter at least 10 characters for analysis...';
        resultDiv.className = 'demo-result';
        return;
    }
    
    resultDiv.textContent = 'Analyzing...';
    resultDiv.className = 'demo-result loading';
    
    const message = {
        action: 'classify',
        text: text.trim()
    };
    
    chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
            resultDiv.textContent = 'Error: Could not analyze text. Make sure you\'re on a Reddit page first.';
            resultDiv.className = 'demo-result';
            return;
        }
        
        if (!response || response.error) {
            resultDiv.textContent = 'Error: ' + (response?.error || 'Classification failed');
            resultDiv.className = 'demo-result';
            return;
        }
        
        // Handle classification result
        const topPrediction = Array.isArray(response) ? response[0] : response;
        
        if (topPrediction && topPrediction.label === 'llm' && topPrediction.score > 0.5) {
            // Clear previous content
            resultDiv.innerHTML = '';
            
            // Create elements safely
            const icon = document.createTextNode('🤖 ');
            const title = document.createElement('strong');
            title.textContent = 'AI Detected';
            const br1 = document.createElement('br');
            const confidence = document.createTextNode(`Confidence: ${(topPrediction.score * 100).toFixed(1)}%`);
            const br2 = document.createElement('br');
            const description = document.createTextNode('This text appears to be AI-generated.');
            
            // Append elements
            resultDiv.appendChild(icon);
            resultDiv.appendChild(title);
            resultDiv.appendChild(br1);
            resultDiv.appendChild(confidence);
            resultDiv.appendChild(br2);
            resultDiv.appendChild(description);
            
            resultDiv.className = 'demo-result ai-detected';
        } else {
            // For human detection, use the score directly if label is 'human', otherwise invert the llm score
            let confidence;
            if (topPrediction?.label === 'human') {
                confidence = (topPrediction.score * 100).toFixed(1);
            } else if (topPrediction?.label === 'llm') {
                confidence = ((1 - topPrediction.score) * 100).toFixed(1);
            } else {
                confidence = '50.0';
            }
            // Clear previous content
            resultDiv.innerHTML = '';
            
            // Create elements safely
            const icon = document.createTextNode('✅ ');
            const title = document.createElement('strong');
            title.textContent = 'Human Detected';
            const br1 = document.createElement('br');
            const confidenceText = document.createTextNode(`Confidence: ${confidence}%`);
            const br2 = document.createElement('br');
            const description = document.createTextNode('This text appears to be human-written.');
            
            // Append elements
            resultDiv.appendChild(icon);
            resultDiv.appendChild(title);
            resultDiv.appendChild(br1);
            resultDiv.appendChild(confidenceText);
            resultDiv.appendChild(br2);
            resultDiv.appendChild(description);
            
            resultDiv.className = 'demo-result human-detected';
        }
    });
}

// Initialize popup
document.addEventListener('DOMContentLoaded', async () => {
    const settings = await loadSettings();
    
    // Set checkbox states from saved settings
    document.getElementById('showProgress').checked = settings.showProgress;
    document.getElementById('showUserScores').checked = settings.showUserScores;
    document.getElementById('highlightComments').checked = settings.highlightComments;
    document.getElementById('showHumanIndicators').checked = settings.showHumanIndicators;
    document.getElementById('autoAnalyze').checked = settings.autoAnalyze;
    
    // Set aggression level radio button
    const aggressionRadio = document.querySelector(`input[name="aggression"][value="${settings.aggressionLevel}"]`);
    if (aggressionRadio) {
        aggressionRadio.checked = true;
    }
    
    // Set selected model
    const modelSelect = document.getElementById('modelSelect');
    if (modelSelect) {
        modelSelect.value = settings.selectedModel;
    }
    
    // Add event listeners for all checkboxes
    const checkboxes = ['showProgress', 'showUserScores', 'highlightComments', 'showHumanIndicators', 'autoAnalyze'];
    
    checkboxes.forEach(id => {
        document.getElementById(id).addEventListener('change', async (event) => {
            const currentSettings = await loadSettings();
            currentSettings[id] = event.target.checked;
            saveSettings(currentSettings);
            
            // Notify content script of settings change
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]) {
                    chrome.tabs.sendMessage(tabs[0].id, {
                        action: 'settingsChanged',
                        settings: currentSettings
                    }).catch(() => {
                        // Ignore errors if content script isn't loaded
                    });
                }
            });
        });
    });
    
    // Add event listeners for aggression level radio buttons
    const aggressionRadios = document.querySelectorAll('input[name="aggression"]');
    aggressionRadios.forEach(radio => {
        radio.addEventListener('change', async (event) => {
            if (event.target.checked) {
                const currentSettings = await loadSettings();
                currentSettings.aggressionLevel = event.target.value;
                saveSettings(currentSettings);
                
                // Notify content script of settings change
                chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                    if (tabs[0]) {
                        chrome.tabs.sendMessage(tabs[0].id, {
                            action: 'settingsChanged',
                            settings: currentSettings
                        }).catch(() => {
                            // Ignore errors if content script isn't loaded
                        });
                    }
                });
            }
        });
    });
    
    // Add event listener for model selection
    if (modelSelect) {
        modelSelect.addEventListener('change', async (event) => {
            const currentSettings = await loadSettings();
            currentSettings.selectedModel = event.target.value;
            saveSettings(currentSettings);
            
            // Notify background script that model changed (it needs to reload)
            chrome.runtime.sendMessage({
                action: 'modelChanged',
                model: event.target.value
            }).catch(() => {
                // Ignore errors if background script isn't ready
            });
            
            // Notify content script of settings change
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]) {
                    chrome.tabs.sendMessage(tabs[0].id, {
                        action: 'settingsChanged',
                        settings: currentSettings
                    }).catch(() => {
                        // Ignore errors if content script isn't loaded
                    });
                }
            });
        });
    }
    
    // Clear data button
    document.getElementById('clearData').addEventListener('click', () => {
        if (confirm('Are you sure you want to clear all stored user data and scores?')) {
            chrome.storage.local.remove('reddit-user-scores');
            
            // Notify content script to refresh displays
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]) {
                    chrome.tabs.sendMessage(tabs[0].id, {
                        action: 'clearData'
                    }).catch(() => {
                        // Ignore errors if content script isn't loaded
                    });
                }
            });
            
            alert('All user data has been cleared!');
        }
    });
    
    // Analyze now button
    document.getElementById('analyzeNow').addEventListener('click', () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    action: 'analyzeNow'
                }).catch(() => {
                    alert('Please make sure you are on a Reddit page to analyze comments.');
                });
            }
        });
        
        // Close popup after triggering analysis
        window.close();
    });
    
    // Demo text input with debouncing
    const demoTextInput = document.getElementById('demoText');
    demoTextInput.addEventListener('input', (event) => {
        const text = event.target.value;
        
        // Clear previous timeout
        if (demoTimeout) {
            clearTimeout(demoTimeout);
        }
        
        // Debounce input to avoid too many API calls
        demoTimeout = setTimeout(() => {
            classifyDemoText(text);
        }, 800); // Wait 800ms after user stops typing
    });
    
    // Also trigger on Enter key
    demoTextInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            if (demoTimeout) {
                clearTimeout(demoTimeout);
            }
            classifyDemoText(event.target.value);
        }
    });
});

// Export settings functions for potential use by other scripts
window.getSettings = loadSettings;
window.saveSettings = saveSettings;
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9wdXAuanMiLCJtYXBwaW5ncyI6Ijs7VUFBQTtVQUNBOzs7OztXQ0RBO1dBQ0E7V0FDQTtXQUNBLHVEQUF1RCxpQkFBaUI7V0FDeEU7V0FDQSxnREFBZ0QsYUFBYTtXQUM3RDs7Ozs7Ozs7O0FDTkE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpREFBaUQsaUNBQWlDO0FBQ2xGO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNULE1BQU07QUFDTjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBbUMsMEJBQTBCO0FBQzdEO0FBQ0EsU0FBUztBQUNULE1BQU07QUFDTjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzRUFBc0UsdUNBQXVDO0FBQzdHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWM7QUFDZDtBQUNBLGNBQWM7QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBFQUEwRSxXQUFXO0FBQ3JGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNGQUFzRix5QkFBeUI7QUFDL0c7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdDQUFnQyxtQ0FBbUM7QUFDbkU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQSxxQkFBcUI7QUFDckI7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNULEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DLG1DQUFtQztBQUN2RTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxnQ0FBZ0MsbUNBQW1DO0FBQ25FO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLG1DQUFtQztBQUNuRTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQSxxQkFBcUI7QUFDckI7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixtQ0FBbUM7QUFDL0Q7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyxRQUFRO0FBQ2pCLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxDQUFDOztBQUVEO0FBQ0E7QUFDQSxtQyIsInNvdXJjZXMiOlsid2VicGFjazovL3JlZGRpdC1haS1jb21tZW50LWRldGVjdG9yL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL3JlZGRpdC1haS1jb21tZW50LWRldGVjdG9yL3dlYnBhY2svcnVudGltZS9tYWtlIG5hbWVzcGFjZSBvYmplY3QiLCJ3ZWJwYWNrOi8vcmVkZGl0LWFpLWNvbW1lbnQtZGV0ZWN0b3IvLi9zcmMvcG9wdXAuanMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGhlIHJlcXVpcmUgc2NvcGVcbnZhciBfX3dlYnBhY2tfcmVxdWlyZV9fID0ge307XG5cbiIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsIi8vIHBvcHVwLmpzIC0gU2V0dGluZ3MgYW5kIGNvbnRyb2xzIGZvciB0aGUgUmVkZGl0IEFJIENvbW1lbnQgRGV0ZWN0b3IgZXh0ZW5zaW9uXG5cbi8vIENvbmZpZ3VyYXRpb24gc3RvcmFnZSBrZXlcbmNvbnN0IFNFVFRJTkdTX0tFWSA9ICdyZWRkaXQtYWktZGV0ZWN0b3Itc2V0dGluZ3MnO1xuXG4vLyBEZWZhdWx0IHNldHRpbmdzXG5jb25zdCBERUZBVUxUX1NFVFRJTkdTID0ge1xuICAgIHNob3dQcm9ncmVzczogdHJ1ZSxcbiAgICBzaG93VXNlclNjb3JlczogdHJ1ZSxcbiAgICBoaWdobGlnaHRDb21tZW50czogdHJ1ZSxcbiAgICBzaG93SHVtYW5JbmRpY2F0b3JzOiBmYWxzZSxcbiAgICBhdXRvQW5hbHl6ZTogdHJ1ZSxcbiAgICBhZ2dyZXNzaW9uTGV2ZWw6ICdsb3cnLFxuICAgIHNlbGVjdGVkTW9kZWw6ICd0cmVudG1rZWxseS9zbG9wLWRldGVjdG9yLW1pbmktMidcbn07XG5cbi8vIExvYWQgc2V0dGluZ3MgZnJvbSBzdG9yYWdlXG5mdW5jdGlvbiBsb2FkU2V0dGluZ3MoKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoW1NFVFRJTkdTX0tFWV0sIChyZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBzdG9yZWQgPSByZXN1bHRbU0VUVElOR1NfS0VZXTtcbiAgICAgICAgICAgICAgICBjb25zdCBmaW5hbFNldHRpbmdzID0gc3RvcmVkID8geyAuLi5ERUZBVUxUX1NFVFRJTkdTLCAuLi5zdG9yZWQgfSA6IERFRkFVTFRfU0VUVElOR1M7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ1BvcHVwIHNldHRpbmdzIGxvYWRlZDonLCBmaW5hbFNldHRpbmdzKTtcbiAgICAgICAgICAgICAgICByZXNvbHZlKGZpbmFsU2V0dGluZ3MpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBsb2FkIHNldHRpbmdzOicsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShERUZBVUxUX1NFVFRJTkdTKTtcbiAgICB9XG59XG5cbi8vIFNhdmUgc2V0dGluZ3MgdG8gc3RvcmFnZVxuZnVuY3Rpb24gc2F2ZVNldHRpbmdzKHNldHRpbmdzKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NFVFRJTkdTX0tFWV06IHNldHRpbmdzIH0sICgpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdTZXR0aW5ncyBzYXZlZDonLCBzZXR0aW5ncyk7XG4gICAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBzYXZlIHNldHRpbmdzOicsIGVycm9yKTtcbiAgICB9XG59XG5cbi8vIERlbW8gZnVuY3Rpb25hbGl0eVxubGV0IGRlbW9UaW1lb3V0ID0gbnVsbDtcblxuZnVuY3Rpb24gY2xhc3NpZnlEZW1vVGV4dCh0ZXh0KSB7XG4gICAgY29uc3QgcmVzdWx0RGl2ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2RlbW9SZXN1bHQnKTtcbiAgICBcbiAgICBpZiAoIXRleHQgfHwgdGV4dC50cmltKCkubGVuZ3RoIDwgMTApIHtcbiAgICAgICAgcmVzdWx0RGl2LnRleHRDb250ZW50ID0gdGV4dC50cmltKCkubGVuZ3RoID09PSAwID8gJycgOiAnRW50ZXIgYXQgbGVhc3QgMTAgY2hhcmFjdGVycyBmb3IgYW5hbHlzaXMuLi4nO1xuICAgICAgICByZXN1bHREaXYuY2xhc3NOYW1lID0gJ2RlbW8tcmVzdWx0JztcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBcbiAgICByZXN1bHREaXYudGV4dENvbnRlbnQgPSAnQW5hbHl6aW5nLi4uJztcbiAgICByZXN1bHREaXYuY2xhc3NOYW1lID0gJ2RlbW8tcmVzdWx0IGxvYWRpbmcnO1xuICAgIFxuICAgIGNvbnN0IG1lc3NhZ2UgPSB7XG4gICAgICAgIGFjdGlvbjogJ2NsYXNzaWZ5JyxcbiAgICAgICAgdGV4dDogdGV4dC50cmltKClcbiAgICB9O1xuICAgIFxuICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKG1lc3NhZ2UsIChyZXNwb25zZSkgPT4ge1xuICAgICAgICBpZiAoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yKSB7XG4gICAgICAgICAgICByZXN1bHREaXYudGV4dENvbnRlbnQgPSAnRXJyb3I6IENvdWxkIG5vdCBhbmFseXplIHRleHQuIE1ha2Ugc3VyZSB5b3VcXCdyZSBvbiBhIFJlZGRpdCBwYWdlIGZpcnN0Lic7XG4gICAgICAgICAgICByZXN1bHREaXYuY2xhc3NOYW1lID0gJ2RlbW8tcmVzdWx0JztcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgaWYgKCFyZXNwb25zZSB8fCByZXNwb25zZS5lcnJvcikge1xuICAgICAgICAgICAgcmVzdWx0RGl2LnRleHRDb250ZW50ID0gJ0Vycm9yOiAnICsgKHJlc3BvbnNlPy5lcnJvciB8fCAnQ2xhc3NpZmljYXRpb24gZmFpbGVkJyk7XG4gICAgICAgICAgICByZXN1bHREaXYuY2xhc3NOYW1lID0gJ2RlbW8tcmVzdWx0JztcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgLy8gSGFuZGxlIGNsYXNzaWZpY2F0aW9uIHJlc3VsdFxuICAgICAgICBjb25zdCB0b3BQcmVkaWN0aW9uID0gQXJyYXkuaXNBcnJheShyZXNwb25zZSkgPyByZXNwb25zZVswXSA6IHJlc3BvbnNlO1xuICAgICAgICBcbiAgICAgICAgaWYgKHRvcFByZWRpY3Rpb24gJiYgdG9wUHJlZGljdGlvbi5sYWJlbCA9PT0gJ2xsbScgJiYgdG9wUHJlZGljdGlvbi5zY29yZSA+IDAuNSkge1xuICAgICAgICAgICAgLy8gQ2xlYXIgcHJldmlvdXMgY29udGVudFxuICAgICAgICAgICAgcmVzdWx0RGl2LmlubmVySFRNTCA9ICcnO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICAvLyBDcmVhdGUgZWxlbWVudHMgc2FmZWx5XG4gICAgICAgICAgICBjb25zdCBpY29uID0gZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoJ/CfpJYgJyk7XG4gICAgICAgICAgICBjb25zdCB0aXRsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0cm9uZycpO1xuICAgICAgICAgICAgdGl0bGUudGV4dENvbnRlbnQgPSAnQUkgRGV0ZWN0ZWQnO1xuICAgICAgICAgICAgY29uc3QgYnIxID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYnInKTtcbiAgICAgICAgICAgIGNvbnN0IGNvbmZpZGVuY2UgPSBkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShgQ29uZmlkZW5jZTogJHsodG9wUHJlZGljdGlvbi5zY29yZSAqIDEwMCkudG9GaXhlZCgxKX0lYCk7XG4gICAgICAgICAgICBjb25zdCBicjIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdicicpO1xuICAgICAgICAgICAgY29uc3QgZGVzY3JpcHRpb24gPSBkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZSgnVGhpcyB0ZXh0IGFwcGVhcnMgdG8gYmUgQUktZ2VuZXJhdGVkLicpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICAvLyBBcHBlbmQgZWxlbWVudHNcbiAgICAgICAgICAgIHJlc3VsdERpdi5hcHBlbmRDaGlsZChpY29uKTtcbiAgICAgICAgICAgIHJlc3VsdERpdi5hcHBlbmRDaGlsZCh0aXRsZSk7XG4gICAgICAgICAgICByZXN1bHREaXYuYXBwZW5kQ2hpbGQoYnIxKTtcbiAgICAgICAgICAgIHJlc3VsdERpdi5hcHBlbmRDaGlsZChjb25maWRlbmNlKTtcbiAgICAgICAgICAgIHJlc3VsdERpdi5hcHBlbmRDaGlsZChicjIpO1xuICAgICAgICAgICAgcmVzdWx0RGl2LmFwcGVuZENoaWxkKGRlc2NyaXB0aW9uKTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgcmVzdWx0RGl2LmNsYXNzTmFtZSA9ICdkZW1vLXJlc3VsdCBhaS1kZXRlY3RlZCc7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBGb3IgaHVtYW4gZGV0ZWN0aW9uLCB1c2UgdGhlIHNjb3JlIGRpcmVjdGx5IGlmIGxhYmVsIGlzICdodW1hbicsIG90aGVyd2lzZSBpbnZlcnQgdGhlIGxsbSBzY29yZVxuICAgICAgICAgICAgbGV0IGNvbmZpZGVuY2U7XG4gICAgICAgICAgICBpZiAodG9wUHJlZGljdGlvbj8ubGFiZWwgPT09ICdodW1hbicpIHtcbiAgICAgICAgICAgICAgICBjb25maWRlbmNlID0gKHRvcFByZWRpY3Rpb24uc2NvcmUgKiAxMDApLnRvRml4ZWQoMSk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHRvcFByZWRpY3Rpb24/LmxhYmVsID09PSAnbGxtJykge1xuICAgICAgICAgICAgICAgIGNvbmZpZGVuY2UgPSAoKDEgLSB0b3BQcmVkaWN0aW9uLnNjb3JlKSAqIDEwMCkudG9GaXhlZCgxKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgY29uZmlkZW5jZSA9ICc1MC4wJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIENsZWFyIHByZXZpb3VzIGNvbnRlbnRcbiAgICAgICAgICAgIHJlc3VsdERpdi5pbm5lckhUTUwgPSAnJztcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLy8gQ3JlYXRlIGVsZW1lbnRzIHNhZmVseVxuICAgICAgICAgICAgY29uc3QgaWNvbiA9IGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKCfinIUgJyk7XG4gICAgICAgICAgICBjb25zdCB0aXRsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0cm9uZycpO1xuICAgICAgICAgICAgdGl0bGUudGV4dENvbnRlbnQgPSAnSHVtYW4gRGV0ZWN0ZWQnO1xuICAgICAgICAgICAgY29uc3QgYnIxID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYnInKTtcbiAgICAgICAgICAgIGNvbnN0IGNvbmZpZGVuY2VUZXh0ID0gZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoYENvbmZpZGVuY2U6ICR7Y29uZmlkZW5jZX0lYCk7XG4gICAgICAgICAgICBjb25zdCBicjIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdicicpO1xuICAgICAgICAgICAgY29uc3QgZGVzY3JpcHRpb24gPSBkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZSgnVGhpcyB0ZXh0IGFwcGVhcnMgdG8gYmUgaHVtYW4td3JpdHRlbi4nKTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLy8gQXBwZW5kIGVsZW1lbnRzXG4gICAgICAgICAgICByZXN1bHREaXYuYXBwZW5kQ2hpbGQoaWNvbik7XG4gICAgICAgICAgICByZXN1bHREaXYuYXBwZW5kQ2hpbGQodGl0bGUpO1xuICAgICAgICAgICAgcmVzdWx0RGl2LmFwcGVuZENoaWxkKGJyMSk7XG4gICAgICAgICAgICByZXN1bHREaXYuYXBwZW5kQ2hpbGQoY29uZmlkZW5jZVRleHQpO1xuICAgICAgICAgICAgcmVzdWx0RGl2LmFwcGVuZENoaWxkKGJyMik7XG4gICAgICAgICAgICByZXN1bHREaXYuYXBwZW5kQ2hpbGQoZGVzY3JpcHRpb24pO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICByZXN1bHREaXYuY2xhc3NOYW1lID0gJ2RlbW8tcmVzdWx0IGh1bWFuLWRldGVjdGVkJztcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG4vLyBJbml0aWFsaXplIHBvcHVwXG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdET01Db250ZW50TG9hZGVkJywgYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgbG9hZFNldHRpbmdzKCk7XG4gICAgXG4gICAgLy8gU2V0IGNoZWNrYm94IHN0YXRlcyBmcm9tIHNhdmVkIHNldHRpbmdzXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Nob3dQcm9ncmVzcycpLmNoZWNrZWQgPSBzZXR0aW5ncy5zaG93UHJvZ3Jlc3M7XG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Nob3dVc2VyU2NvcmVzJykuY2hlY2tlZCA9IHNldHRpbmdzLnNob3dVc2VyU2NvcmVzO1xuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdoaWdobGlnaHRDb21tZW50cycpLmNoZWNrZWQgPSBzZXR0aW5ncy5oaWdobGlnaHRDb21tZW50cztcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc2hvd0h1bWFuSW5kaWNhdG9ycycpLmNoZWNrZWQgPSBzZXR0aW5ncy5zaG93SHVtYW5JbmRpY2F0b3JzO1xuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdhdXRvQW5hbHl6ZScpLmNoZWNrZWQgPSBzZXR0aW5ncy5hdXRvQW5hbHl6ZTtcbiAgICBcbiAgICAvLyBTZXQgYWdncmVzc2lvbiBsZXZlbCByYWRpbyBidXR0b25cbiAgICBjb25zdCBhZ2dyZXNzaW9uUmFkaW8gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGBpbnB1dFtuYW1lPVwiYWdncmVzc2lvblwiXVt2YWx1ZT1cIiR7c2V0dGluZ3MuYWdncmVzc2lvbkxldmVsfVwiXWApO1xuICAgIGlmIChhZ2dyZXNzaW9uUmFkaW8pIHtcbiAgICAgICAgYWdncmVzc2lvblJhZGlvLmNoZWNrZWQgPSB0cnVlO1xuICAgIH1cbiAgICBcbiAgICAvLyBTZXQgc2VsZWN0ZWQgbW9kZWxcbiAgICBjb25zdCBtb2RlbFNlbGVjdCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdtb2RlbFNlbGVjdCcpO1xuICAgIGlmIChtb2RlbFNlbGVjdCkge1xuICAgICAgICBtb2RlbFNlbGVjdC52YWx1ZSA9IHNldHRpbmdzLnNlbGVjdGVkTW9kZWw7XG4gICAgfVxuICAgIFxuICAgIC8vIEFkZCBldmVudCBsaXN0ZW5lcnMgZm9yIGFsbCBjaGVja2JveGVzXG4gICAgY29uc3QgY2hlY2tib3hlcyA9IFsnc2hvd1Byb2dyZXNzJywgJ3Nob3dVc2VyU2NvcmVzJywgJ2hpZ2hsaWdodENvbW1lbnRzJywgJ3Nob3dIdW1hbkluZGljYXRvcnMnLCAnYXV0b0FuYWx5emUnXTtcbiAgICBcbiAgICBjaGVja2JveGVzLmZvckVhY2goaWQgPT4ge1xuICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChpZCkuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgYXN5bmMgKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50U2V0dGluZ3MgPSBhd2FpdCBsb2FkU2V0dGluZ3MoKTtcbiAgICAgICAgICAgIGN1cnJlbnRTZXR0aW5nc1tpZF0gPSBldmVudC50YXJnZXQuY2hlY2tlZDtcbiAgICAgICAgICAgIHNhdmVTZXR0aW5ncyhjdXJyZW50U2V0dGluZ3MpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICAvLyBOb3RpZnkgY29udGVudCBzY3JpcHQgb2Ygc2V0dGluZ3MgY2hhbmdlXG4gICAgICAgICAgICBjaHJvbWUudGFicy5xdWVyeSh7IGFjdGl2ZTogdHJ1ZSwgY3VycmVudFdpbmRvdzogdHJ1ZSB9LCAodGFicykgPT4ge1xuICAgICAgICAgICAgICAgIGlmICh0YWJzWzBdKSB7XG4gICAgICAgICAgICAgICAgICAgIGNocm9tZS50YWJzLnNlbmRNZXNzYWdlKHRhYnNbMF0uaWQsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbjogJ3NldHRpbmdzQ2hhbmdlZCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXR0aW5nczogY3VycmVudFNldHRpbmdzXG4gICAgICAgICAgICAgICAgICAgIH0pLmNhdGNoKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIElnbm9yZSBlcnJvcnMgaWYgY29udGVudCBzY3JpcHQgaXNuJ3QgbG9hZGVkXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9KTtcbiAgICBcbiAgICAvLyBBZGQgZXZlbnQgbGlzdGVuZXJzIGZvciBhZ2dyZXNzaW9uIGxldmVsIHJhZGlvIGJ1dHRvbnNcbiAgICBjb25zdCBhZ2dyZXNzaW9uUmFkaW9zID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnaW5wdXRbbmFtZT1cImFnZ3Jlc3Npb25cIl0nKTtcbiAgICBhZ2dyZXNzaW9uUmFkaW9zLmZvckVhY2gocmFkaW8gPT4ge1xuICAgICAgICByYWRpby5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCBhc3luYyAoZXZlbnQpID0+IHtcbiAgICAgICAgICAgIGlmIChldmVudC50YXJnZXQuY2hlY2tlZCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRTZXR0aW5ncyA9IGF3YWl0IGxvYWRTZXR0aW5ncygpO1xuICAgICAgICAgICAgICAgIGN1cnJlbnRTZXR0aW5ncy5hZ2dyZXNzaW9uTGV2ZWwgPSBldmVudC50YXJnZXQudmFsdWU7XG4gICAgICAgICAgICAgICAgc2F2ZVNldHRpbmdzKGN1cnJlbnRTZXR0aW5ncyk7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgLy8gTm90aWZ5IGNvbnRlbnQgc2NyaXB0IG9mIHNldHRpbmdzIGNoYW5nZVxuICAgICAgICAgICAgICAgIGNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0sICh0YWJzKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0YWJzWzBdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWJzWzBdLmlkLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uOiAnc2V0dGluZ3NDaGFuZ2VkJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXR0aW5nczogY3VycmVudFNldHRpbmdzXG4gICAgICAgICAgICAgICAgICAgICAgICB9KS5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSWdub3JlIGVycm9ycyBpZiBjb250ZW50IHNjcmlwdCBpc24ndCBsb2FkZWRcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0pO1xuICAgIFxuICAgIC8vIEFkZCBldmVudCBsaXN0ZW5lciBmb3IgbW9kZWwgc2VsZWN0aW9uXG4gICAgaWYgKG1vZGVsU2VsZWN0KSB7XG4gICAgICAgIG1vZGVsU2VsZWN0LmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsIGFzeW5jIChldmVudCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgY3VycmVudFNldHRpbmdzID0gYXdhaXQgbG9hZFNldHRpbmdzKCk7XG4gICAgICAgICAgICBjdXJyZW50U2V0dGluZ3Muc2VsZWN0ZWRNb2RlbCA9IGV2ZW50LnRhcmdldC52YWx1ZTtcbiAgICAgICAgICAgIHNhdmVTZXR0aW5ncyhjdXJyZW50U2V0dGluZ3MpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICAvLyBOb3RpZnkgYmFja2dyb3VuZCBzY3JpcHQgdGhhdCBtb2RlbCBjaGFuZ2VkIChpdCBuZWVkcyB0byByZWxvYWQpXG4gICAgICAgICAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7XG4gICAgICAgICAgICAgICAgYWN0aW9uOiAnbW9kZWxDaGFuZ2VkJyxcbiAgICAgICAgICAgICAgICBtb2RlbDogZXZlbnQudGFyZ2V0LnZhbHVlXG4gICAgICAgICAgICB9KS5jYXRjaCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgLy8gSWdub3JlIGVycm9ycyBpZiBiYWNrZ3JvdW5kIHNjcmlwdCBpc24ndCByZWFkeVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIC8vIE5vdGlmeSBjb250ZW50IHNjcmlwdCBvZiBzZXR0aW5ncyBjaGFuZ2VcbiAgICAgICAgICAgIGNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0sICh0YWJzKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHRhYnNbMF0pIHtcbiAgICAgICAgICAgICAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFic1swXS5pZCwge1xuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uOiAnc2V0dGluZ3NDaGFuZ2VkJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldHRpbmdzOiBjdXJyZW50U2V0dGluZ3NcbiAgICAgICAgICAgICAgICAgICAgfSkuY2F0Y2goKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gSWdub3JlIGVycm9ycyBpZiBjb250ZW50IHNjcmlwdCBpc24ndCBsb2FkZWRcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBcbiAgICAvLyBDbGVhciBkYXRhIGJ1dHRvblxuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdjbGVhckRhdGEnKS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICAgICAgaWYgKGNvbmZpcm0oJ0FyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBjbGVhciBhbGwgc3RvcmVkIHVzZXIgZGF0YSBhbmQgc2NvcmVzPycpKSB7XG4gICAgICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5yZW1vdmUoJ3JlZGRpdC11c2VyLXNjb3JlcycpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICAvLyBOb3RpZnkgY29udGVudCBzY3JpcHQgdG8gcmVmcmVzaCBkaXNwbGF5c1xuICAgICAgICAgICAgY2hyb21lLnRhYnMucXVlcnkoeyBhY3RpdmU6IHRydWUsIGN1cnJlbnRXaW5kb3c6IHRydWUgfSwgKHRhYnMpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAodGFic1swXSkge1xuICAgICAgICAgICAgICAgICAgICBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWJzWzBdLmlkLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb246ICdjbGVhckRhdGEnXG4gICAgICAgICAgICAgICAgICAgIH0pLmNhdGNoKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIElnbm9yZSBlcnJvcnMgaWYgY29udGVudCBzY3JpcHQgaXNuJ3QgbG9hZGVkXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBhbGVydCgnQWxsIHVzZXIgZGF0YSBoYXMgYmVlbiBjbGVhcmVkIScpO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgXG4gICAgLy8gQW5hbHl6ZSBub3cgYnV0dG9uXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2FuYWx5emVOb3cnKS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICAgICAgY2hyb21lLnRhYnMucXVlcnkoeyBhY3RpdmU6IHRydWUsIGN1cnJlbnRXaW5kb3c6IHRydWUgfSwgKHRhYnMpID0+IHtcbiAgICAgICAgICAgIGlmICh0YWJzWzBdKSB7XG4gICAgICAgICAgICAgICAgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFic1swXS5pZCwge1xuICAgICAgICAgICAgICAgICAgICBhY3Rpb246ICdhbmFseXplTm93J1xuICAgICAgICAgICAgICAgIH0pLmNhdGNoKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgYWxlcnQoJ1BsZWFzZSBtYWtlIHN1cmUgeW91IGFyZSBvbiBhIFJlZGRpdCBwYWdlIHRvIGFuYWx5emUgY29tbWVudHMuJyk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICBcbiAgICAgICAgLy8gQ2xvc2UgcG9wdXAgYWZ0ZXIgdHJpZ2dlcmluZyBhbmFseXNpc1xuICAgICAgICB3aW5kb3cuY2xvc2UoKTtcbiAgICB9KTtcbiAgICBcbiAgICAvLyBEZW1vIHRleHQgaW5wdXQgd2l0aCBkZWJvdW5jaW5nXG4gICAgY29uc3QgZGVtb1RleHRJbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkZW1vVGV4dCcpO1xuICAgIGRlbW9UZXh0SW5wdXQuYWRkRXZlbnRMaXN0ZW5lcignaW5wdXQnLCAoZXZlbnQpID0+IHtcbiAgICAgICAgY29uc3QgdGV4dCA9IGV2ZW50LnRhcmdldC52YWx1ZTtcbiAgICAgICAgXG4gICAgICAgIC8vIENsZWFyIHByZXZpb3VzIHRpbWVvdXRcbiAgICAgICAgaWYgKGRlbW9UaW1lb3V0KSB7XG4gICAgICAgICAgICBjbGVhclRpbWVvdXQoZGVtb1RpbWVvdXQpO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICAvLyBEZWJvdW5jZSBpbnB1dCB0byBhdm9pZCB0b28gbWFueSBBUEkgY2FsbHNcbiAgICAgICAgZGVtb1RpbWVvdXQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIGNsYXNzaWZ5RGVtb1RleHQodGV4dCk7XG4gICAgICAgIH0sIDgwMCk7IC8vIFdhaXQgODAwbXMgYWZ0ZXIgdXNlciBzdG9wcyB0eXBpbmdcbiAgICB9KTtcbiAgICBcbiAgICAvLyBBbHNvIHRyaWdnZXIgb24gRW50ZXIga2V5XG4gICAgZGVtb1RleHRJbnB1dC5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgKGV2ZW50KSA9PiB7XG4gICAgICAgIGlmIChldmVudC5rZXkgPT09ICdFbnRlcicgJiYgIWV2ZW50LnNoaWZ0S2V5KSB7XG4gICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgaWYgKGRlbW9UaW1lb3V0KSB7XG4gICAgICAgICAgICAgICAgY2xlYXJUaW1lb3V0KGRlbW9UaW1lb3V0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNsYXNzaWZ5RGVtb1RleHQoZXZlbnQudGFyZ2V0LnZhbHVlKTtcbiAgICAgICAgfVxuICAgIH0pO1xufSk7XG5cbi8vIEV4cG9ydCBzZXR0aW5ncyBmdW5jdGlvbnMgZm9yIHBvdGVudGlhbCB1c2UgYnkgb3RoZXIgc2NyaXB0c1xud2luZG93LmdldFNldHRpbmdzID0gbG9hZFNldHRpbmdzO1xud2luZG93LnNhdmVTZXR0aW5ncyA9IHNhdmVTZXR0aW5nczsiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=