/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
/*!************************!*\
  !*** ./src/content.js ***!
  \************************/
__webpack_require__.r(__webpack_exports__);
// content.js - Reddit comment classifier
// Detects and classifies Reddit comments, highlighting those identified as LLM-generated

// Settings management
const SETTINGS_KEY = 'reddit-ai-detector-settings';
const DEFAULT_SETTINGS = {
    showProgress: true,
    showUserScores: true,
    highlightComments: true,
    showHumanIndicators: false,
    autoAnalyze: true,
    aggressionLevel: 'low'
};

let currentSettings = DEFAULT_SETTINGS;

// Load settings from storage
function loadSettings() {
    return new Promise((resolve) => {
        try {
            chrome.storage.local.get([SETTINGS_KEY], (result) => {
                const stored = result[SETTINGS_KEY];
                console.log('🔧 SETTINGS DEBUG: Raw stored settings:', stored);
                const finalSettings = stored ? { ...DEFAULT_SETTINGS, ...stored } : DEFAULT_SETTINGS;
                console.log('🔧 SETTINGS DEBUG: Final merged settings:', finalSettings);
                resolve(finalSettings);
            });
        } catch (error) {
            console.error('Failed to load settings:', error);
            resolve(DEFAULT_SETTINGS);
        }
    });
}

// Initialize settings asynchronously
loadSettings().then(settings => {
    currentSettings = settings;
    console.log('🔧 SETTINGS DEBUG: Initial settings loaded:', currentSettings);
    console.log('🔧 SETTINGS DEBUG: Initial aggression level:', currentSettings.aggressionLevel);
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'settingsChanged') {
        console.log('🔧 SETTINGS DEBUG: Received settings change message:', message.settings);
        console.log('🔧 SETTINGS DEBUG: Old settings:', currentSettings);
        currentSettings = message.settings;
        console.log('🔧 SETTINGS DEBUG: New settings applied:', currentSettings);
        console.log('🔧 SETTINGS DEBUG: Aggression level is now:', currentSettings.aggressionLevel);
        
        // Update displays based on new settings
        if (currentSettings.showUserScores) {
            userScoreManager.updateAllUserDisplays();
        } else {
            // Remove all user score badges
            document.querySelectorAll('.user-score-badge').forEach(badge => badge.remove());
        }
        
        sendResponse({ success: true });
    } else if (message.action === 'clearData') {
        // Clear processed comments and reload user data
        processedComments.clear();
        userScoreManager.loadUserData();
        userScoreManager.updateAllUserDisplays();
        
        // Remove all highlights and indicators
        document.querySelectorAll('[data-llm-highlighted]').forEach(el => {
            el.style.cssText = '';
            el.removeAttribute('data-llm-highlighted');
        });
        document.querySelectorAll('.llm-warning-badge').forEach(badge => badge.remove());
        document.querySelectorAll('.human-indicator').forEach(indicator => indicator.remove());
        
        sendResponse({ success: true });
    } else if (message.action === 'analyzeNow') {
        processAllComments();
        sendResponse({ success: true });
    }
});

// CSS selectors for different Reddit variants
const REDDIT_SELECTORS = {
    // Old Reddit
    oldReddit: {
        comments: '.comment .usertext-body .md',
        commentContainer: '.comment'
    },
    // New Reddit
    newReddit: {
        comments: 'shreddit-profile-comment .md p, shreddit-comment .md p, [data-testid="comment"] p, div[id*="post-rtjson-content"] p, .RichTextJSON-root p, .Comment p',
        commentContainer: 'shreddit-profile-comment, shreddit-comment, [data-testid="comment"]'
    },
    // General selectors that might work across variants
    general: {
        comments: '.usertext-body p, [role="article"] p, .Comment p, .commentarea p, shreddit-profile-comment .md p, shreddit-comment .md p, div[id*="post-rtjson-content"] p',
        commentContainer: '.comment, [data-testid="comment"], [role="article"], shreddit-profile-comment, shreddit-comment'
    }
};

// Track processed comments to avoid duplicate processing
const processedComments = new Set();

// User scoring system
class UserScoreManager {
    constructor() {
        this.storageKey = 'reddit-user-scores';
        this.loadUserData();
    }
    
    loadUserData() {
        chrome.storage.local.get([this.storageKey], (result) => {
            try {
                this.userData = result[this.storageKey] || {};
                console.log('User data loaded:', Object.keys(this.userData).length, 'users');
            } catch (error) {
                console.error('Failed to load user data:', error);
                this.userData = {};
            }
        });
    }
    
    saveUserData() {
        try {
            chrome.storage.local.set({ [this.storageKey]: this.userData }, () => {
                console.log('User data saved');
            });
        } catch (error) {
            console.error('Failed to save user data:', error);
        }
    }
    
    updateUserScore(username, commentId, isAI, confidence) {
        if (!username || !commentId) return;
        
        // Initialize user data if not exists
        if (!this.userData[username]) {
            this.userData[username] = {
                score: 0,
                comments: {}
            };
        }
        
        // Check if we've already scored this comment
        if (this.userData[username].comments[commentId]) {
            console.log(`Already scored comment ${commentId} for user ${username}`);
            return false; // Return false to indicate no new processing
        }
        
        // Calculate score delta - simplified scoring
        let scoreDelta;
        if (isAI) {
            // AI comments get -1 point
            scoreDelta = -1;
        } else {
            // Human comments get +1 point
            scoreDelta = 1;
        }
        
        // Update user score and record comment
        this.userData[username].score += scoreDelta;
        this.userData[username].comments[commentId] = {
            isAI,
            confidence,
            scoreDelta,
            timestamp: Date.now()
        };
        
        this.saveUserData();
        this.updateUserDisplay(username);
        
        console.log(`Updated score for ${username}: ${this.userData[username].score} (${scoreDelta > 0 ? '+' : ''}${scoreDelta})`);
        return true; // Return true to indicate new processing
    }
    
    // Check if a comment has already been processed
    isCommentProcessed(username, commentId) {
        if (!username || !commentId) return false;
        return this.userData[username]?.comments[commentId] !== undefined;
    }
    
    // Get cached comment result
    getCachedCommentResult(username, commentId) {
        if (!username || !commentId) return null;
        return this.userData[username]?.comments[commentId];
    }
    
    getUserScore(username) {
        return this.userData[username]?.score || 0;
    }
    
    updateUserDisplay(username) {
        // Find all instances of this username and update their displays
        const userElements = document.querySelectorAll(`a[href*="/user/${username}"], a[href*="/u/${username}"]`);
        userElements.forEach(element => this.addScoreToElement(element, username));
        
        // Also look for author elements without links (old Reddit)
        const authorElements = document.querySelectorAll('.author');
        authorElements.forEach(element => {
            if (element.textContent?.trim() === username) {
                this.addScoreToElement(element, username);
            }
        });
    }
    
    addScoreToElement(element, username) {
        // Check if user scores should be displayed
        if (!currentSettings.showUserScores) {
            return;
        }
        
        // Avoid adding multiple score badges
        if (element.querySelector('.user-score-badge')) {
            return;
        }
        
        const userData = this.userData[username];
        if (!userData || !userData.comments) return;
        
        const comments = Object.values(userData.comments);
        const totalComments = comments.length;
        const aiComments = comments.filter(comment => comment.isAI).length;
        
        if (totalComments === 0) return; // Don't show if no comments analyzed
        
        const aiPercentage = Math.round((aiComments / totalComments) * 100);
        
        // Color coding based on AI percentage
        let backgroundColor, textColor;
        if (aiPercentage < 20) {
            backgroundColor = 'rgba(76, 175, 80, 0.8)'; // Green
            textColor = 'white';
        } else if (aiPercentage <= 40) {
            backgroundColor = 'rgba(255, 152, 0, 0.8)'; // Orange/Yellow
            textColor = 'white';
        } else {
            backgroundColor = 'rgba(244, 67, 54, 0.8)'; // Red
            textColor = 'white';
        }
        
        const badge = document.createElement('span');
        badge.className = 'user-score-badge';
        badge.style.cssText = `
            margin-left: 4px;
            padding: 1px 4px;
            border-radius: 4px;
            font-size: 9px;
            font-weight: 500;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            white-space: nowrap;
            opacity: 0.7;
            background: ${backgroundColor};
            color: ${textColor};
        `;
        
        badge.textContent = `AI: ${aiPercentage}% (${aiComments}/${totalComments})`;
        
        let riskLevel;
        if (aiPercentage < 20) {
            riskLevel = 'Low Risk';
        } else if (aiPercentage <= 40) {
            riskLevel = 'Medium Risk';
        } else {
            riskLevel = 'High Risk';
        }
        
        badge.title = `AI Detection: ${riskLevel} - ${aiPercentage}% of comments flagged as AI (${aiComments}/${totalComments} comments)`;
        
        element.appendChild(badge);
    }
    
    // Update all visible usernames with scores
    updateAllUserDisplays() {
        // Find all username links
        const userLinks = document.querySelectorAll('a[href*="/user/"], a[href*="/u/"]');
        userLinks.forEach(link => {
            const href = link.getAttribute('href');
            const username = href.match(/\/u(?:ser)?\/([^\/\?\#]+)/)?.[1];
            if (username && this.userData[username]) {
                this.addScoreToElement(link, username);
            }
        });
        
        // Find all author elements (old Reddit)
        const authorElements = document.querySelectorAll('.author');
        authorElements.forEach(element => {
            const username = element.textContent?.trim();
            if (username && this.userData[username] && username !== '[deleted]') {
                this.addScoreToElement(element, username);
            }
        });
        
        // Find elements with author-name attribute (new Reddit)
        const authorNameElements = document.querySelectorAll('[author-name]');
        authorNameElements.forEach(element => {
            const username = element.getAttribute('author-name');
            if (username && this.userData[username] && username !== '[deleted]') {
                this.addScoreToElement(element, username);
            }
        });
    }
}

// Initialize user score manager
const userScoreManager = new UserScoreManager();

// Progress tracking
let progressWidget = null;
let totalComments = 0;
let processedCount = 0;

// Create floating progress widget
function createProgressWidget() {
    // Check if progress widget should be displayed
    if (!currentSettings.showProgress) {
        return null;
    }
    const widget = document.createElement('div');
    widget.id = 'llm-detector-progress';
    widget.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 300px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        padding: 16px;
        color: white;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 14px;
        z-index: 10000;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        transition: all 0.3s ease;
        animation: slideIn 0.3s ease-out;
    `;
    
    widget.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <div style="display: flex; align-items: center; gap: 8px;">
                <div style="width: 16px; height: 16px; background: #ff9800; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px;">🤖</div>
                <span style="font-weight: 600; font-size: 13px;">AI Comment Detector</span>
            </div>
            <button id="close-progress" style="background: none; border: none; color: rgba(255,255,255,0.7); cursor: pointer; font-size: 18px; line-height: 1; padding: 0; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; border-radius: 4px; transition: all 0.2s;">×</button>
        </div>
        <div style="margin-bottom: 8px;">
            <div id="progress-text" style="font-size: 12px; color: rgba(255,255,255,0.9); margin-bottom: 6px;">Scanning comments...</div>
            <div style="background: rgba(255,255,255,0.2); border-radius: 8px; height: 6px; overflow: hidden;">
                <div id="progress-bar" style="background: linear-gradient(90deg, #00f2fe 0%, #4facfe 100%); height: 100%; width: 0%; transition: width 0.3s ease; border-radius: 8px;"></div>
            </div>
        </div>
        <div id="status-text" style="font-size: 11px; color: rgba(255,255,255,0.7);">Initializing...</div>
    `;
    
    // Add slide-in animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        #llm-detector-progress:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.4);
        }
        #close-progress:hover {
            background: rgba(255,255,255,0.2) !important;
            color: white !important;
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(widget);
    
    // Add close functionality
    document.getElementById('close-progress').addEventListener('click', () => {
        widget.style.animation = 'slideOut 0.3s ease-in forwards';
        setTimeout(() => widget.remove(), 300);
    });
    
    // Add slide-out animation
    style.textContent += `
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    
    return widget;
}

// Update progress widget
function updateProgress(processed, total, status = '') {
    // Check if progress should be shown
    if (!currentSettings.showProgress) {
        return;
    }
    
    // Check if widget still exists and recreate if needed
    if (!progressWidget || !document.body.contains(progressWidget)) {
        if (progressWidget) {
            progressWidget.remove();
        }
        progressWidget = createProgressWidget();
    }
    
    // If progressWidget is null (settings disabled), return early
    if (!progressWidget) {
        return;
    }
    
    const progressBar = progressWidget.querySelector('#progress-bar');
    const progressText = progressWidget.querySelector('#progress-text');
    const statusText = progressWidget.querySelector('#status-text');
    
    const percentage = total > 0 ? Math.round((processed / total) * 100) : 0;
    
    if (progressBar) {
        progressBar.style.width = `${percentage}%`;
    }
    
    if (progressText) {
        progressText.textContent = `Analyzing comments: ${processed}/${total} (${percentage}%)`;
    }
    
    if (statusText) {
        statusText.textContent = status || `${processed} comments processed`;
    }
    
    // Auto-hide when complete
    if (processed >= total && total > 0) {
        setTimeout(() => {
            if (progressWidget && progressWidget.parentNode) {
                progressWidget.style.animation = 'slideOut 0.3s ease-in forwards';
                setTimeout(() => {
                    if (progressWidget && progressWidget.parentNode) {
                        progressWidget.remove();
                        progressWidget = null;
                    }
                }, 300);
            }
        }, 2000);
    }
}

// Function to detect Reddit variant
function detectRedditVariant() {
    const hostname = window.location.hostname;
    if (hostname.includes('old.reddit')) return 'oldReddit';
    if (hostname.includes('sh.reddit')) return 'newReddit'; // sh.reddit uses new reddit UI
    if (hostname.includes('reddit.com')) return 'newReddit';
    return 'general';
}

// Function to get comment text content
function getCommentText(element) {
    // Remove any nested quotes or other comments to get just the main comment text
    const clone = element.cloneNode(true);
    
    // Remove quoted text and other nested elements that aren't part of the main comment
    const quotes = clone.querySelectorAll('blockquote, .md-spoiler-text');
    quotes.forEach(quote => quote.remove());
    
    return clone.textContent?.trim() || '';
}

// Function to check if model is ready
async function ensureModelReady() {
    return new Promise((resolve) => {
        // Send a test message to ensure the model is loaded
        const testMessage = {
            action: 'classify',
            text: 'Test message to initialize model'
        };
        
        console.log('Checking if model is ready...');
        
        chrome.runtime.sendMessage(testMessage, (response) => {
            if (chrome.runtime.lastError) {
                console.error('Model ready check failed:', chrome.runtime.lastError);
                resolve(false);
            } else if (response && response.error) {
                console.error('Model ready check error:', response.error);
                resolve(false);
            } else {
                console.log('Model is ready for classification');
                resolve(true);
            }
        });
    });
}

// Function to classify a comment
async function classifyComment(text, retryCount = 0) {
    if (!text || text.length < 10) return null; // Skip very short comments
    
    try {
        const message = {
            action: 'classify',
            text: text
        };
        
        console.log('Sending message to background script:', message);
        
        return new Promise((resolve) => {
            chrome.runtime.sendMessage(message, (response) => {
                console.log('Received response from background script:', response);
                if (chrome.runtime.lastError) {
                    console.error('Chrome runtime error:', chrome.runtime.lastError);
                    resolve(null);
                } else if (response && response.error) {
                    console.error('Background script error:', response.error);
                    
                    // Retry session errors once after a delay
                    if ((response.error.includes('Session') || response.error.includes('session')) && retryCount < 1) {
                        console.log('Retrying after session error...');
                        setTimeout(() => {
                            classifyComment(text, retryCount + 1).then(resolve);
                        }, 3000);
                        return;
                    }
                    
                    resolve(null);
                } else {
                    resolve(response);
                }
            });
        });
    } catch (error) {
        console.error('Error classifying comment:', error);
        return null;
    }
}

// Function to highlight LLM-detected comment
function highlightLLMComment(commentElement) {
    // Check if comment highlighting should be shown
    if (!currentSettings.highlightComments) {
        return;
    }
    
    // Avoid highlighting the same element multiple times
    if (commentElement.dataset.llmHighlighted) {
        return;
    }
    commentElement.dataset.llmHighlighted = 'true';
    
    // Find the closest container (comment container)
    const container = commentElement.closest('shreddit-profile-comment, shreddit-comment, [data-testid="comment"], .comment') || commentElement.parentElement;
    
    if (!container) return;
    
    // Add non-destructive styling to the container
    container.style.cssText += `
        position: relative;
        background: linear-gradient(45deg, rgba(255, 193, 7, 0.05), rgba(255, 152, 0, 0.05)) !important;
        border-left: 4px solid #ff9800 !important;
        border-radius: 8px !important;
        box-shadow: 0 2px 8px rgba(255, 152, 0, 0.2) !important;
        margin: 8px 0 !important;
    `;
    
    // Create warning badge as floating overlay (non-destructive)
    const warning = document.createElement('div');
    warning.className = 'llm-warning-badge';
    warning.style.cssText = `
        position: absolute;
        bottom: -12px;
        left: 50%;
        transform: translateX(-50%);
        background: linear-gradient(135deg, #ff9800, #ff6f00);
        color: white;
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        z-index: 10000;
        box-shadow: 0 2px 6px rgba(255, 152, 0, 0.4);
        border: 2px solid white;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        pointer-events: none;
        white-space: nowrap;
    `;
    warning.innerHTML = `⚠️ May be AI-generated`;
    
    // Insert the badge without moving existing elements or affecting layout
    container.style.position = 'relative';
    container.appendChild(warning);
}

// Function to mark human-written comment with small indicator
function markHumanComment(commentElement) {
    // Check if human indicators should be shown
    if (!currentSettings.showHumanIndicators) {
        return;
    }
    
    // Avoid marking the same element multiple times
    if (commentElement.dataset.humanMarked) {
        return;
    }
    commentElement.dataset.humanMarked = 'true';
    
    // Find the closest container (comment container)
    const container = commentElement.closest('shreddit-profile-comment, shreddit-comment, [data-testid="comment"], .comment') || commentElement.parentElement;
    
    if (!container) return;
    
    // Create small progress indicator as floating overlay (non-destructive)
    const indicator = document.createElement('div');
    indicator.className = 'human-indicator';
    indicator.style.cssText = `
        position: absolute;
        bottom: -8px;
        right: 8px;
        background: rgba(76, 175, 80, 0.8);
        color: white;
        padding: 2px 6px;
        border-radius: 8px;
        font-size: 9px;
        font-weight: 500;
        z-index: 9999;
        box-shadow: 0 1px 3px rgba(76, 175, 80, 0.3);
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        pointer-events: none;
        opacity: 0.6;
        white-space: nowrap;
    `;
    indicator.innerHTML = `✓ Human`;
    
    // Insert the indicator without moving existing elements or affecting layout
    container.style.position = 'relative';
    container.appendChild(indicator);
}

// Function to minimize/collapse a comment (for High aggression)
function minimizeComment(commentElement) {
    console.log('🔍 MINIMIZE DEBUG: Starting minimizeComment function');
    console.log('🔍 MINIMIZE DEBUG: Comment element:', commentElement);
    
    const container = commentElement.closest('shreddit-profile-comment, shreddit-comment, [data-testid="comment"], .comment');
    console.log('🔍 MINIMIZE DEBUG: Found container:', container);
    
    if (!container) {
        console.log('🔍 MINIMIZE DEBUG: No container found, returning false');
        return false;
    }
    
    try {
        // Old Reddit - look for collapse/expand button
        console.log('🔍 MINIMIZE DEBUG: Looking for old Reddit expand button...');
        const expandButton = container.querySelector('.expand[onclick*="togglecomment"]');
        console.log('🔍 MINIMIZE DEBUG: Old Reddit expand button found:', expandButton);
        
        if (expandButton) {
            console.log('🔍 MINIMIZE DEBUG: Clicking old Reddit expand button');
            expandButton.click();
            console.log('✅ MINIMIZE SUCCESS: Minimized comment using old Reddit expand button');
            return true;
        }
        
        // Try alternative old Reddit selectors
        console.log('🔍 MINIMIZE DEBUG: Trying alternative old Reddit selectors...');
        const altExpandButton = container.querySelector('.expand, a[onclick*="togglecomment"], [onclick*="collapse"]');
        console.log('🔍 MINIMIZE DEBUG: Alternative expand button found:', altExpandButton);
        
        if (altExpandButton) {
            console.log('🔍 MINIMIZE DEBUG: Clicking alternative expand button');
            altExpandButton.click();
            console.log('✅ MINIMIZE SUCCESS: Minimized comment using alternative expand button');
            return true;
        }
        
        // New Reddit - look for collapse button
        console.log('🔍 MINIMIZE DEBUG: Looking for new Reddit collapse button...');
        const collapseButton = container.querySelector('button[aria-label*="collapse"], button[aria-label*="Collapse"]');
        console.log('🔍 MINIMIZE DEBUG: New Reddit collapse button found:', collapseButton);
        
        if (collapseButton) {
            console.log('🔍 MINIMIZE DEBUG: Clicking new Reddit collapse button');
            collapseButton.click();
            console.log('✅ MINIMIZE SUCCESS: Minimized comment using new Reddit collapse button');
            return true;
        }
        
        // Try more new Reddit selectors
        console.log('🔍 MINIMIZE DEBUG: Trying more new Reddit selectors...');
        const moreCollapseButtons = container.querySelectorAll('button[data-testid*="collapse"], button[title*="collapse"], button[title*="Collapse"]');
        console.log('🔍 MINIMIZE DEBUG: Additional collapse buttons found:', moreCollapseButtons);
        
        if (moreCollapseButtons.length > 0) {
            console.log('🔍 MINIMIZE DEBUG: Clicking first additional collapse button');
            moreCollapseButtons[0].click();
            console.log('✅ MINIMIZE SUCCESS: Minimized comment using additional collapse button');
            return true;
        }
        
        // Fallback - hide the comment body manually
        console.log('🔍 MINIMIZE DEBUG: No native buttons found, trying fallback method...');
        const commentBody = container.querySelector('.usertext-body, .md, [data-testid="comment-content"]');
        console.log('🔍 MINIMIZE DEBUG: Comment body found for fallback:', commentBody);
        
        if (commentBody) {
            console.log('🔍 MINIMIZE DEBUG: Hiding comment body manually');
            commentBody.style.display = 'none';
            
            // Add a small indicator that the comment was auto-minimized
            const indicator = document.createElement('div');
            indicator.className = 'auto-minimized-indicator';
            indicator.style.cssText = `
                font-size: 11px;
                color: #ff9800;
                font-style: italic;
                margin: 4px 0;
                padding: 2px 4px;
                background: rgba(255, 152, 0, 0.1);
                border-radius: 3px;
                display: inline-block;
                cursor: pointer;
            `;
            indicator.textContent = '🤖 Auto-minimized (suspected AI) - Click to expand';
            indicator.onclick = () => {
                console.log('🔍 MINIMIZE DEBUG: User clicked to expand comment');
                commentBody.style.display = '';
                indicator.remove();
            };
            
            commentBody.parentNode.insertBefore(indicator, commentBody);
            console.log('✅ MINIMIZE SUCCESS: Manually minimized comment with fallback method');
            return true;
        }
        
        console.log('❌ MINIMIZE FAILED: No comment body found for fallback');
        return false;
    } catch (error) {
        console.error('❌ MINIMIZE ERROR: Error minimizing comment:', error);
        return false;
    }
}

// Function to apply aggression-based actions to AI-detected comments
function applyAggressionActions(commentElement) {
    console.log('🔍 AGGRESSION DEBUG: Applying aggression actions');
    console.log('🔍 AGGRESSION DEBUG: Current settings object:', currentSettings);
    console.log('🔍 AGGRESSION DEBUG: Aggression level:', currentSettings.aggressionLevel);
    console.log('🔍 AGGRESSION DEBUG: Aggression level type:', typeof currentSettings.aggressionLevel);
    
    if (currentSettings.aggressionLevel === 'low') {
        console.log('🔍 AGGRESSION DEBUG: Low aggression - no additional actions');
        return;
    }
    
    if (currentSettings.aggressionLevel === 'high') {
        console.log('🔍 AGGRESSION DEBUG: High aggression - minimizing comment');
        const minimized = minimizeComment(commentElement);
        if (minimized) {
            console.log('✅ AGGRESSION SUCCESS: Auto-minimized AI comment due to high aggression level');
        } else {
            console.log('❌ AGGRESSION FAILED: Could not minimize AI comment');
        }
    }
}

// Function to extract username from comment element
function extractUsername(commentElement) {
    // Try multiple strategies to find the username, being very specific to avoid profile page confusion
    const container = commentElement.closest('shreddit-profile-comment, shreddit-comment, [data-testid="comment"], .comment');
    if (!container) return null;
    
    // Strategy 1: New Reddit profile comments - look for author name in the comment header
    if (container.tagName === 'SHREDDIT-PROFILE-COMMENT') {
        // Look for the author name specifically within this comment's metadata
        const authorLink = container.querySelector('a[href*="/user/"], a[href*="/u/"]');
        if (authorLink) {
            const href = authorLink.getAttribute('href');
            const username = href.match(/\/u(?:ser)?\/([^\/\?\#]+)/)?.[1];
            if (username && username !== '[deleted]') return username;
        }
    }
    
    // Strategy 2: Old Reddit - look for .author class but ensure it's within the comment's tagline, not the parent post
    const authorEl = container.querySelector('.tagline .author');
    if (authorEl) {
        const text = authorEl.textContent?.trim();
        if (text && text !== '[deleted]' && !text.includes(' ') && text.length > 0) {
            return text;
        }
    }
    
    // Strategy 3: New Reddit - look for author-name attribute on elements within the comment
    const authorNameEl = container.querySelector('[author-name]');
    if (authorNameEl) {
        const authorName = authorNameEl.getAttribute('author-name');
        if (authorName && authorName !== '[deleted]') return authorName;
    }
    
    // Strategy 4: Look for username links but prioritize ones in comment metadata, not post titles
    const userLinks = container.querySelectorAll('a[href*="/user/"], a[href*="/u/"]');
    for (const link of userLinks) {
        // Skip links that are in post titles or other content
        const linkText = link.textContent?.trim();
        const href = link.getAttribute('href');
        const username = href.match(/\/u(?:ser)?\/([^\/\?\#]+)/)?.[1];
        
        // Check if this link is likely the comment author (not in post content)
        const isInCommentMeta = link.closest('.tagline, [id*="poster-info"], .comment-meta, faceplate-hovercard');
        if (username && username !== '[deleted]' && (isInCommentMeta || linkText === username)) {
            return username;
        }
    }
    
    // Strategy 5: Look for data-author attribute
    const dataAuthorEl = container.querySelector('[data-author]');
    if (dataAuthorEl) {
        const author = dataAuthorEl.getAttribute('data-author');
        if (author && author !== '[deleted]') return author;
    }
    
    // Strategy 6: New Reddit specific - look for poster info within the comment
    const posterInfo = container.querySelector('[id*="poster-info"]');
    if (posterInfo) {
        const userLink = posterInfo.querySelector('a[href*="/user/"], a[href*="/u/"]');
        if (userLink) {
            const href = userLink.getAttribute('href');
            const username = href.match(/\/u(?:ser)?\/([^\/\?\#]+)/)?.[1];
            if (username && username !== '[deleted]') return username;
        }
    }
    
    console.log('Could not extract username from comment:', container);
    return null;
}

// Function to process a single comment
async function processComment(commentElement, index = 0) {
    // Get a more reliable comment ID for profile pages
    const container = commentElement.closest('shreddit-profile-comment, shreddit-comment, [data-testid="comment"], .comment');
    let commentId = null;
    
    // Try multiple strategies to get a unique comment ID
    if (container) {
        commentId = container.getAttribute('comment-id') ||
                   container.getAttribute('data-comment-id') ||
                   container.getAttribute('data-testid') ||
                   container.id;
    }
    
    // Fallback to element attributes
    if (!commentId) {
        commentId = commentElement.getAttribute('data-comment-id') || 
                   commentElement.getAttribute('data-testid') || 
                   commentElement.getAttribute('id');
    }
    
    // Last resort: use a hash of the comment content
    if (!commentId) {
        const text = getCommentText(commentElement);
        commentId = `comment_${text.substring(0, 50).replace(/\s+/g, '_')}`;
    }
    
    if (processedComments.has(commentId)) {
        console.log('Skipping already processed comment');
        processedCount++;
        updateProgress(processedCount, totalComments, 'Skipping duplicate comment');
        return;
    }
    processedComments.add(commentId);
    
    // Extract username
    const username = extractUsername(commentElement);
    
    // Check if we've already processed this comment for this user
    if (username && userScoreManager.isCommentProcessed(username, commentId)) {
        console.log(`Comment ${commentId} already processed for user ${username}, using cached result`);
        const cachedResult = userScoreManager.getCachedCommentResult(username, commentId);
        
        // Apply the visual indicators based on cached result
        if (cachedResult.isAI) {
            highlightLLMComment(commentElement);
            
            // Apply aggression-based actions for cached AI comments too
            applyAggressionActions(commentElement);
            
            updateProgress(processedCount + 1, totalComments, `⚠️ Cached AI comment (${Math.round(cachedResult.confidence * 100)}% confidence)`);
        } else {
            markHumanComment(commentElement);
            updateProgress(processedCount + 1, totalComments, `Cached human comment`);
        }
        
        processedCount++;
        return;
    }
    
    const text = getCommentText(commentElement);
    console.log(`Processing comment (${text.length} chars): "${text.substring(0, 100)}..."`);
    
    updateProgress(processedCount, totalComments, `Processing comment ${processedCount + 1}...`);
    
    if (!text) {
        console.log('Skipping comment - no text content');
        processedCount++;
        updateProgress(processedCount, totalComments, 'Skipping empty comment');
        return;
    }
    
    if (text.length < 10) {
        console.log('Skipping comment - too short');
        processedCount++;
        updateProgress(processedCount, totalComments, 'Skipping short comment');
        return;
    }
    
    console.log('Sending comment for classification...');
    updateProgress(processedCount, totalComments, `Analyzing comment ${processedCount + 1}...`);
    
    const result = await classifyComment(text);
    
    processedCount++;
    
    if (!result) {
        console.log('Classification failed or returned null');
        updateProgress(processedCount, totalComments, 'Classification failed');
        return;
    }
    
    console.log('Classification result:', result);
    
    // Check if the highest confidence prediction is 'llm'
    const topPrediction = Array.isArray(result) ? result[0] : result;
    console.log('Top prediction:', topPrediction);
    
    if (topPrediction && topPrediction.label === 'llm') {
        console.log(`LLM detected with confidence: ${topPrediction.score}`);
        if (topPrediction.score > 0.5) {
            highlightLLMComment(commentElement);
            
            // Apply aggression-based actions (minimize/downvote)
            applyAggressionActions(commentElement);
            
            // Update user score for AI comment
            if (username) {
                userScoreManager.updateUserScore(username, commentId, true, topPrediction.score);
            }
            console.log('🚨 LLM comment highlighted:', text.substring(0, 100) + '...', topPrediction);
            updateProgress(processedCount, totalComments, `⚠️ Possible AI comment (${Math.round(topPrediction.score * 100)}% confidence)`);
        } else {
            console.log('LLM confidence too low, not highlighting');
            markHumanComment(commentElement);
            // Update user score for human comment
            if (username) {
                userScoreManager.updateUserScore(username, commentId, false, topPrediction.score);
            }
            updateProgress(processedCount, totalComments, `Human comment (low AI confidence)`);
        }
    } else {
        console.log(`Human comment detected: ${topPrediction?.label} (${topPrediction?.score})`);
        markHumanComment(commentElement);
        // Update user score for human comment
        if (username) {
            userScoreManager.updateUserScore(username, commentId, false, topPrediction?.score || 0.5);
        }
        updateProgress(processedCount, totalComments, `Human comment detected`);
    }
}

// Function to find and process all comments
async function processAllComments() {
    console.log('Starting to process all comments...');
    
    // Reset progress tracking
    processedCount = 0;
    totalComments = 0;
    
    // Create progress widget
    if (progressWidget) {
        progressWidget.remove();
    }
    progressWidget = createProgressWidget();
    
    // Ensure model is ready before processing
    updateProgress(0, 0, 'Loading AI model...');
    const modelReady = await ensureModelReady();
    if (!modelReady) {
        updateProgress(0, 0, 'Failed to load AI model');
        setTimeout(() => {
            if (progressWidget && progressWidget.parentNode) {
                progressWidget.remove();
            }
        }, 3000);
        return;
    }
    
    const variant = detectRedditVariant();
    console.log(`Detected Reddit variant: ${variant}`);
    const selectors = REDDIT_SELECTORS[variant];
    
    // Try multiple selector strategies
    const selectorSets = [selectors, REDDIT_SELECTORS.general];
    
    for (const selectorSet of selectorSets) {
        console.log(`Trying selector: ${selectorSet.comments}`);
        const comments = document.querySelectorAll(selectorSet.comments);
        console.log(`Found ${comments.length} comments with this selector`);
        
        if (comments.length > 0) {
            console.log(`✅ Found ${comments.length} comments using ${variant} selectors`);
            
            // Process all comments found
            totalComments = comments.length;
            console.log(`Processing all ${totalComments} comments...`);
            
            updateProgress(0, totalComments, 'Starting analysis...');
            
            for (let i = 0; i < totalComments; i++) {
                console.log(`Processing comment ${i + 1}/${totalComments}`);
                processComment(comments[i], i); // No delay between comments
            }
            break;
        }
    }
    
    if (totalComments === 0) {
        updateProgress(0, 0, 'No comments found to analyze');
        setTimeout(() => {
            if (progressWidget && progressWidget.parentNode) {
                progressWidget.remove();
            }
        }, 3000);
    }
    
    // Update existing user displays
    setTimeout(() => {
        userScoreManager.updateAllUserDisplays();
    }, 2000);
    
    console.log('Finished queueing comments for processing');
}

// Initial processing - start immediately since we now check model readiness
setTimeout(() => {
    if (currentSettings.autoAnalyze) {
        processAllComments();
    }
}, 1000);

// Update user displays on page load
setTimeout(() => {
    userScoreManager.updateAllUserDisplays();
}, 2000);

// Watch for dynamically loaded content
const observer = new MutationObserver((mutations) => {
    let shouldProcess = false;
    
    mutations.forEach((mutation) => {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
            // Check if new nodes contain comments
            mutation.addedNodes.forEach((node) => {
                if (node.nodeType === Node.ELEMENT_NODE) {
                    const variant = detectRedditVariant();
                    const selectors = REDDIT_SELECTORS[variant];
                    
                    if (node.matches && (
                        node.matches(selectors.comments) || 
                        node.matches(selectors.commentContainer) ||
                        node.querySelector(selectors.comments)
                    )) {
                        shouldProcess = true;
                    }
                }
            });
        }
    });
    
    if (shouldProcess) {
        if (currentSettings.autoAnalyze) {
            setTimeout(processAllComments, 500);
        }
        // Also update user displays when new content loads
        setTimeout(() => {
            userScoreManager.updateAllUserDisplays();
        }, 1000);
    }
});

// Start observing
observer.observe(document.body, {
    childList: true,
    subtree: true
});

// Also process when page navigation occurs (for SPA behavior)
let currentUrl = window.location.href;
setInterval(() => {
    if (window.location.href !== currentUrl) {
        currentUrl = window.location.href;
        processedComments.clear();
        if (currentSettings.autoAnalyze) {
            setTimeout(processAllComments, 2000);
        }
    }
}, 1000);

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC5qcyIsIm1hcHBpbmdzIjoiOztVQUFBO1VBQ0E7Ozs7O1dDREE7V0FDQTtXQUNBO1dBQ0EsdURBQXVELGlCQUFpQjtXQUN4RTtXQUNBLGdEQUFnRCxhQUFhO1dBQzdEOzs7Ozs7Ozs7QUNOQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaURBQWlELGlDQUFpQztBQUNsRjtBQUNBO0FBQ0EsYUFBYTtBQUNiLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLGVBQWU7QUFDdEMsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsZUFBZTtBQUN0QyxNQUFNO0FBQ047QUFDQSx1QkFBdUIsZUFBZTtBQUN0QztBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWM7QUFDZDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1Q0FBdUMsa0NBQWtDO0FBQ3pFO0FBQ0EsYUFBYTtBQUNiLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0RBQWtELFdBQVcsV0FBVyxTQUFTO0FBQ2pGLDBCQUEwQjtBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QyxTQUFTLElBQUksK0JBQStCLEdBQUcsMEJBQTBCLEVBQUUsV0FBVztBQUMvSCxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlFQUF5RSxTQUFTLGtCQUFrQixTQUFTO0FBQzdHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QztBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3REFBd0Q7QUFDeEQ7QUFDQSxVQUFVO0FBQ1Ysd0RBQXdEO0FBQ3hEO0FBQ0EsVUFBVTtBQUNWLHdEQUF3RDtBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMEJBQTBCO0FBQzFCLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0EsbUNBQW1DLGFBQWEsS0FBSyxXQUFXLEdBQUcsY0FBYztBQUNqRjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQSx1Q0FBdUMsV0FBVyxJQUFJLGFBQWEsK0JBQStCLFdBQVcsR0FBRyxlQUFlO0FBQy9IO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1DQUFtQyxnQ0FBZ0MscUJBQXFCLG9CQUFvQjtBQUM1Ryx1Q0FBdUMscUJBQXFCLFNBQVM7QUFDckUseUNBQXlDLGNBQWMscUJBQXFCLG9CQUFvQixlQUFlLHFCQUFxQix5QkFBeUIsZ0JBQWdCO0FBQzdLLCtDQUErQyxnQkFBZ0I7QUFDL0Q7QUFDQSxpRUFBaUUsY0FBYyw4QkFBOEIsaUJBQWlCLGlCQUFpQixnQkFBZ0IsWUFBWSxhQUFhLGNBQWMsZUFBZSxxQkFBcUIseUJBQXlCLG9CQUFvQixxQkFBcUI7QUFDNVM7QUFDQSx1Q0FBdUM7QUFDdkMsNERBQTRELDhCQUE4QixtQkFBbUI7QUFDN0csMkRBQTJELG9CQUFvQixhQUFhLGlCQUFpQjtBQUM3Ryw0R0FBNEcsY0FBYyxXQUFXLDZCQUE2QixtQkFBbUI7QUFDckw7QUFDQTtBQUNBLHNEQUFzRCw2QkFBNkI7QUFDbkY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLDZCQUE2QjtBQUNoRCxpQkFBaUIsMEJBQTBCO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQiwwQkFBMEI7QUFDN0MsaUJBQWlCLDZCQUE2QjtBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQyxXQUFXO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBLDBEQUEwRCxVQUFVLEdBQUcsT0FBTyxHQUFHLFdBQVc7QUFDNUY7QUFDQTtBQUNBO0FBQ0EsOENBQThDLFdBQVc7QUFDekQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsU0FBUztBQUNUO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0REFBNEQ7QUFDNUQ7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYztBQUNkO0FBQ0E7QUFDQSxjQUFjO0FBQ2Q7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTDs7QUFFQTtBQUNBO0FBQ0EsZ0RBQWdEO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QjtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVCxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLDJDQUEyQztBQUMxRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsV0FBVyw2QkFBNkIsU0FBUztBQUNoRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1RkFBdUYsMENBQTBDO0FBQ2pJLFVBQVU7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1Q0FBdUMsYUFBYSxXQUFXLHVCQUF1QjtBQUN0RjtBQUNBLHdFQUF3RSxtQkFBbUI7QUFDM0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1RUFBdUUsbUJBQW1CO0FBQzFGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFEQUFxRCxvQkFBb0I7QUFDekU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFGQUFxRixzQ0FBc0M7QUFDM0gsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNO0FBQ04sK0NBQStDLHNCQUFzQixHQUFHLHFCQUFxQjtBQUM3RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0Q0FBNEMsUUFBUTtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0MscUJBQXFCO0FBQzdEO0FBQ0EsNkJBQTZCLGlCQUFpQjtBQUM5QztBQUNBO0FBQ0EsbUNBQW1DLGlCQUFpQixpQkFBaUIsU0FBUztBQUM5RTtBQUNBO0FBQ0E7QUFDQSwwQ0FBMEMsZUFBZTtBQUN6RDtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsbUJBQW1CO0FBQy9DLGtEQUFrRCxNQUFNLEdBQUcsY0FBYztBQUN6RSxnREFBZ0Q7QUFDaEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3JlZGRpdC1haS1jb21tZW50LWRldGVjdG9yLWZpcmVmb3gvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vcmVkZGl0LWFpLWNvbW1lbnQtZGV0ZWN0b3ItZmlyZWZveC93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovL3JlZGRpdC1haS1jb21tZW50LWRldGVjdG9yLWZpcmVmb3gvLi9zcmMvY29udGVudC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGUgcmVxdWlyZSBzY29wZVxudmFyIF9fd2VicGFja19yZXF1aXJlX18gPSB7fTtcblxuIiwiLy8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5yID0gKGV4cG9ydHMpID0+IHtcblx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG5cdH1cblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbn07IiwiLy8gY29udGVudC5qcyAtIFJlZGRpdCBjb21tZW50IGNsYXNzaWZpZXJcbi8vIERldGVjdHMgYW5kIGNsYXNzaWZpZXMgUmVkZGl0IGNvbW1lbnRzLCBoaWdobGlnaHRpbmcgdGhvc2UgaWRlbnRpZmllZCBhcyBMTE0tZ2VuZXJhdGVkXG5cbi8vIFNldHRpbmdzIG1hbmFnZW1lbnRcbmNvbnN0IFNFVFRJTkdTX0tFWSA9ICdyZWRkaXQtYWktZGV0ZWN0b3Itc2V0dGluZ3MnO1xuY29uc3QgREVGQVVMVF9TRVRUSU5HUyA9IHtcbiAgICBzaG93UHJvZ3Jlc3M6IHRydWUsXG4gICAgc2hvd1VzZXJTY29yZXM6IHRydWUsXG4gICAgaGlnaGxpZ2h0Q29tbWVudHM6IHRydWUsXG4gICAgc2hvd0h1bWFuSW5kaWNhdG9yczogZmFsc2UsXG4gICAgYXV0b0FuYWx5emU6IHRydWUsXG4gICAgYWdncmVzc2lvbkxldmVsOiAnbG93J1xufTtcblxubGV0IGN1cnJlbnRTZXR0aW5ncyA9IERFRkFVTFRfU0VUVElOR1M7XG5cbi8vIExvYWQgc2V0dGluZ3MgZnJvbSBzdG9yYWdlXG5mdW5jdGlvbiBsb2FkU2V0dGluZ3MoKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoW1NFVFRJTkdTX0tFWV0sIChyZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBzdG9yZWQgPSByZXN1bHRbU0VUVElOR1NfS0VZXTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygn8J+UpyBTRVRUSU5HUyBERUJVRzogUmF3IHN0b3JlZCBzZXR0aW5nczonLCBzdG9yZWQpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpbmFsU2V0dGluZ3MgPSBzdG9yZWQgPyB7IC4uLkRFRkFVTFRfU0VUVElOR1MsIC4uLnN0b3JlZCB9IDogREVGQVVMVF9TRVRUSU5HUztcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygn8J+UpyBTRVRUSU5HUyBERUJVRzogRmluYWwgbWVyZ2VkIHNldHRpbmdzOicsIGZpbmFsU2V0dGluZ3MpO1xuICAgICAgICAgICAgICAgIHJlc29sdmUoZmluYWxTZXR0aW5ncyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBsb2FkIHNldHRpbmdzOicsIGVycm9yKTtcbiAgICAgICAgICAgIHJlc29sdmUoREVGQVVMVF9TRVRUSU5HUyk7XG4gICAgICAgIH1cbiAgICB9KTtcbn1cblxuLy8gSW5pdGlhbGl6ZSBzZXR0aW5ncyBhc3luY2hyb25vdXNseVxubG9hZFNldHRpbmdzKCkudGhlbihzZXR0aW5ncyA9PiB7XG4gICAgY3VycmVudFNldHRpbmdzID0gc2V0dGluZ3M7XG4gICAgY29uc29sZS5sb2coJ/CflKcgU0VUVElOR1MgREVCVUc6IEluaXRpYWwgc2V0dGluZ3MgbG9hZGVkOicsIGN1cnJlbnRTZXR0aW5ncyk7XG4gICAgY29uc29sZS5sb2coJ/CflKcgU0VUVElOR1MgREVCVUc6IEluaXRpYWwgYWdncmVzc2lvbiBsZXZlbDonLCBjdXJyZW50U2V0dGluZ3MuYWdncmVzc2lvbkxldmVsKTtcbn0pO1xuXG4vLyBMaXN0ZW4gZm9yIG1lc3NhZ2VzIGZyb20gcG9wdXBcbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobWVzc2FnZSwgc2VuZGVyLCBzZW5kUmVzcG9uc2UpID0+IHtcbiAgICBpZiAobWVzc2FnZS5hY3Rpb24gPT09ICdzZXR0aW5nc0NoYW5nZWQnKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCfwn5SnIFNFVFRJTkdTIERFQlVHOiBSZWNlaXZlZCBzZXR0aW5ncyBjaGFuZ2UgbWVzc2FnZTonLCBtZXNzYWdlLnNldHRpbmdzKTtcbiAgICAgICAgY29uc29sZS5sb2coJ/CflKcgU0VUVElOR1MgREVCVUc6IE9sZCBzZXR0aW5nczonLCBjdXJyZW50U2V0dGluZ3MpO1xuICAgICAgICBjdXJyZW50U2V0dGluZ3MgPSBtZXNzYWdlLnNldHRpbmdzO1xuICAgICAgICBjb25zb2xlLmxvZygn8J+UpyBTRVRUSU5HUyBERUJVRzogTmV3IHNldHRpbmdzIGFwcGxpZWQ6JywgY3VycmVudFNldHRpbmdzKTtcbiAgICAgICAgY29uc29sZS5sb2coJ/CflKcgU0VUVElOR1MgREVCVUc6IEFnZ3Jlc3Npb24gbGV2ZWwgaXMgbm93OicsIGN1cnJlbnRTZXR0aW5ncy5hZ2dyZXNzaW9uTGV2ZWwpO1xuICAgICAgICBcbiAgICAgICAgLy8gVXBkYXRlIGRpc3BsYXlzIGJhc2VkIG9uIG5ldyBzZXR0aW5nc1xuICAgICAgICBpZiAoY3VycmVudFNldHRpbmdzLnNob3dVc2VyU2NvcmVzKSB7XG4gICAgICAgICAgICB1c2VyU2NvcmVNYW5hZ2VyLnVwZGF0ZUFsbFVzZXJEaXNwbGF5cygpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gUmVtb3ZlIGFsbCB1c2VyIHNjb3JlIGJhZGdlc1xuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLnVzZXItc2NvcmUtYmFkZ2UnKS5mb3JFYWNoKGJhZGdlID0+IGJhZGdlLnJlbW92ZSgpKTtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgc2VuZFJlc3BvbnNlKHsgc3VjY2VzczogdHJ1ZSB9KTtcbiAgICB9IGVsc2UgaWYgKG1lc3NhZ2UuYWN0aW9uID09PSAnY2xlYXJEYXRhJykge1xuICAgICAgICAvLyBDbGVhciBwcm9jZXNzZWQgY29tbWVudHMgYW5kIHJlbG9hZCB1c2VyIGRhdGFcbiAgICAgICAgcHJvY2Vzc2VkQ29tbWVudHMuY2xlYXIoKTtcbiAgICAgICAgdXNlclNjb3JlTWFuYWdlci5sb2FkVXNlckRhdGEoKTtcbiAgICAgICAgdXNlclNjb3JlTWFuYWdlci51cGRhdGVBbGxVc2VyRGlzcGxheXMoKTtcbiAgICAgICAgXG4gICAgICAgIC8vIFJlbW92ZSBhbGwgaGlnaGxpZ2h0cyBhbmQgaW5kaWNhdG9yc1xuICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdbZGF0YS1sbG0taGlnaGxpZ2h0ZWRdJykuZm9yRWFjaChlbCA9PiB7XG4gICAgICAgICAgICBlbC5zdHlsZS5jc3NUZXh0ID0gJyc7XG4gICAgICAgICAgICBlbC5yZW1vdmVBdHRyaWJ1dGUoJ2RhdGEtbGxtLWhpZ2hsaWdodGVkJyk7XG4gICAgICAgIH0pO1xuICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcubGxtLXdhcm5pbmctYmFkZ2UnKS5mb3JFYWNoKGJhZGdlID0+IGJhZGdlLnJlbW92ZSgpKTtcbiAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLmh1bWFuLWluZGljYXRvcicpLmZvckVhY2goaW5kaWNhdG9yID0+IGluZGljYXRvci5yZW1vdmUoKSk7XG4gICAgICAgIFxuICAgICAgICBzZW5kUmVzcG9uc2UoeyBzdWNjZXNzOiB0cnVlIH0pO1xuICAgIH0gZWxzZSBpZiAobWVzc2FnZS5hY3Rpb24gPT09ICdhbmFseXplTm93Jykge1xuICAgICAgICBwcm9jZXNzQWxsQ29tbWVudHMoKTtcbiAgICAgICAgc2VuZFJlc3BvbnNlKHsgc3VjY2VzczogdHJ1ZSB9KTtcbiAgICB9XG59KTtcblxuLy8gQ1NTIHNlbGVjdG9ycyBmb3IgZGlmZmVyZW50IFJlZGRpdCB2YXJpYW50c1xuY29uc3QgUkVERElUX1NFTEVDVE9SUyA9IHtcbiAgICAvLyBPbGQgUmVkZGl0XG4gICAgb2xkUmVkZGl0OiB7XG4gICAgICAgIGNvbW1lbnRzOiAnLmNvbW1lbnQgLnVzZXJ0ZXh0LWJvZHkgLm1kJyxcbiAgICAgICAgY29tbWVudENvbnRhaW5lcjogJy5jb21tZW50J1xuICAgIH0sXG4gICAgLy8gTmV3IFJlZGRpdFxuICAgIG5ld1JlZGRpdDoge1xuICAgICAgICBjb21tZW50czogJ3NocmVkZGl0LXByb2ZpbGUtY29tbWVudCAubWQgcCwgc2hyZWRkaXQtY29tbWVudCAubWQgcCwgW2RhdGEtdGVzdGlkPVwiY29tbWVudFwiXSBwLCBkaXZbaWQqPVwicG9zdC1ydGpzb24tY29udGVudFwiXSBwLCAuUmljaFRleHRKU09OLXJvb3QgcCwgLkNvbW1lbnQgcCcsXG4gICAgICAgIGNvbW1lbnRDb250YWluZXI6ICdzaHJlZGRpdC1wcm9maWxlLWNvbW1lbnQsIHNocmVkZGl0LWNvbW1lbnQsIFtkYXRhLXRlc3RpZD1cImNvbW1lbnRcIl0nXG4gICAgfSxcbiAgICAvLyBHZW5lcmFsIHNlbGVjdG9ycyB0aGF0IG1pZ2h0IHdvcmsgYWNyb3NzIHZhcmlhbnRzXG4gICAgZ2VuZXJhbDoge1xuICAgICAgICBjb21tZW50czogJy51c2VydGV4dC1ib2R5IHAsIFtyb2xlPVwiYXJ0aWNsZVwiXSBwLCAuQ29tbWVudCBwLCAuY29tbWVudGFyZWEgcCwgc2hyZWRkaXQtcHJvZmlsZS1jb21tZW50IC5tZCBwLCBzaHJlZGRpdC1jb21tZW50IC5tZCBwLCBkaXZbaWQqPVwicG9zdC1ydGpzb24tY29udGVudFwiXSBwJyxcbiAgICAgICAgY29tbWVudENvbnRhaW5lcjogJy5jb21tZW50LCBbZGF0YS10ZXN0aWQ9XCJjb21tZW50XCJdLCBbcm9sZT1cImFydGljbGVcIl0sIHNocmVkZGl0LXByb2ZpbGUtY29tbWVudCwgc2hyZWRkaXQtY29tbWVudCdcbiAgICB9XG59O1xuXG4vLyBUcmFjayBwcm9jZXNzZWQgY29tbWVudHMgdG8gYXZvaWQgZHVwbGljYXRlIHByb2Nlc3NpbmdcbmNvbnN0IHByb2Nlc3NlZENvbW1lbnRzID0gbmV3IFNldCgpO1xuXG4vLyBVc2VyIHNjb3Jpbmcgc3lzdGVtXG5jbGFzcyBVc2VyU2NvcmVNYW5hZ2VyIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy5zdG9yYWdlS2V5ID0gJ3JlZGRpdC11c2VyLXNjb3Jlcyc7XG4gICAgICAgIHRoaXMubG9hZFVzZXJEYXRhKCk7XG4gICAgfVxuICAgIFxuICAgIGxvYWRVc2VyRGF0YSgpIHtcbiAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFt0aGlzLnN0b3JhZ2VLZXldLCAocmVzdWx0KSA9PiB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHRoaXMudXNlckRhdGEgPSByZXN1bHRbdGhpcy5zdG9yYWdlS2V5XSB8fCB7fTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnVXNlciBkYXRhIGxvYWRlZDonLCBPYmplY3Qua2V5cyh0aGlzLnVzZXJEYXRhKS5sZW5ndGgsICd1c2VycycpO1xuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gbG9hZCB1c2VyIGRhdGE6JywgZXJyb3IpO1xuICAgICAgICAgICAgICAgIHRoaXMudXNlckRhdGEgPSB7fTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuICAgIFxuICAgIHNhdmVVc2VyRGF0YSgpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFt0aGlzLnN0b3JhZ2VLZXldOiB0aGlzLnVzZXJEYXRhIH0sICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnVXNlciBkYXRhIHNhdmVkJyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBzYXZlIHVzZXIgZGF0YTonLCBlcnJvcik7XG4gICAgICAgIH1cbiAgICB9XG4gICAgXG4gICAgdXBkYXRlVXNlclNjb3JlKHVzZXJuYW1lLCBjb21tZW50SWQsIGlzQUksIGNvbmZpZGVuY2UpIHtcbiAgICAgICAgaWYgKCF1c2VybmFtZSB8fCAhY29tbWVudElkKSByZXR1cm47XG4gICAgICAgIFxuICAgICAgICAvLyBJbml0aWFsaXplIHVzZXIgZGF0YSBpZiBub3QgZXhpc3RzXG4gICAgICAgIGlmICghdGhpcy51c2VyRGF0YVt1c2VybmFtZV0pIHtcbiAgICAgICAgICAgIHRoaXMudXNlckRhdGFbdXNlcm5hbWVdID0ge1xuICAgICAgICAgICAgICAgIHNjb3JlOiAwLFxuICAgICAgICAgICAgICAgIGNvbW1lbnRzOiB7fVxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgLy8gQ2hlY2sgaWYgd2UndmUgYWxyZWFkeSBzY29yZWQgdGhpcyBjb21tZW50XG4gICAgICAgIGlmICh0aGlzLnVzZXJEYXRhW3VzZXJuYW1lXS5jb21tZW50c1tjb21tZW50SWRdKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgQWxyZWFkeSBzY29yZWQgY29tbWVudCAke2NvbW1lbnRJZH0gZm9yIHVzZXIgJHt1c2VybmFtZX1gKTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTsgLy8gUmV0dXJuIGZhbHNlIHRvIGluZGljYXRlIG5vIG5ldyBwcm9jZXNzaW5nXG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgIC8vIENhbGN1bGF0ZSBzY29yZSBkZWx0YSAtIHNpbXBsaWZpZWQgc2NvcmluZ1xuICAgICAgICBsZXQgc2NvcmVEZWx0YTtcbiAgICAgICAgaWYgKGlzQUkpIHtcbiAgICAgICAgICAgIC8vIEFJIGNvbW1lbnRzIGdldCAtMSBwb2ludFxuICAgICAgICAgICAgc2NvcmVEZWx0YSA9IC0xO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gSHVtYW4gY29tbWVudHMgZ2V0ICsxIHBvaW50XG4gICAgICAgICAgICBzY29yZURlbHRhID0gMTtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgLy8gVXBkYXRlIHVzZXIgc2NvcmUgYW5kIHJlY29yZCBjb21tZW50XG4gICAgICAgIHRoaXMudXNlckRhdGFbdXNlcm5hbWVdLnNjb3JlICs9IHNjb3JlRGVsdGE7XG4gICAgICAgIHRoaXMudXNlckRhdGFbdXNlcm5hbWVdLmNvbW1lbnRzW2NvbW1lbnRJZF0gPSB7XG4gICAgICAgICAgICBpc0FJLFxuICAgICAgICAgICAgY29uZmlkZW5jZSxcbiAgICAgICAgICAgIHNjb3JlRGVsdGEsXG4gICAgICAgICAgICB0aW1lc3RhbXA6IERhdGUubm93KClcbiAgICAgICAgfTtcbiAgICAgICAgXG4gICAgICAgIHRoaXMuc2F2ZVVzZXJEYXRhKCk7XG4gICAgICAgIHRoaXMudXBkYXRlVXNlckRpc3BsYXkodXNlcm5hbWUpO1xuICAgICAgICBcbiAgICAgICAgY29uc29sZS5sb2coYFVwZGF0ZWQgc2NvcmUgZm9yICR7dXNlcm5hbWV9OiAke3RoaXMudXNlckRhdGFbdXNlcm5hbWVdLnNjb3JlfSAoJHtzY29yZURlbHRhID4gMCA/ICcrJyA6ICcnfSR7c2NvcmVEZWx0YX0pYCk7XG4gICAgICAgIHJldHVybiB0cnVlOyAvLyBSZXR1cm4gdHJ1ZSB0byBpbmRpY2F0ZSBuZXcgcHJvY2Vzc2luZ1xuICAgIH1cbiAgICBcbiAgICAvLyBDaGVjayBpZiBhIGNvbW1lbnQgaGFzIGFscmVhZHkgYmVlbiBwcm9jZXNzZWRcbiAgICBpc0NvbW1lbnRQcm9jZXNzZWQodXNlcm5hbWUsIGNvbW1lbnRJZCkge1xuICAgICAgICBpZiAoIXVzZXJuYW1lIHx8ICFjb21tZW50SWQpIHJldHVybiBmYWxzZTtcbiAgICAgICAgcmV0dXJuIHRoaXMudXNlckRhdGFbdXNlcm5hbWVdPy5jb21tZW50c1tjb21tZW50SWRdICE9PSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIFxuICAgIC8vIEdldCBjYWNoZWQgY29tbWVudCByZXN1bHRcbiAgICBnZXRDYWNoZWRDb21tZW50UmVzdWx0KHVzZXJuYW1lLCBjb21tZW50SWQpIHtcbiAgICAgICAgaWYgKCF1c2VybmFtZSB8fCAhY29tbWVudElkKSByZXR1cm4gbnVsbDtcbiAgICAgICAgcmV0dXJuIHRoaXMudXNlckRhdGFbdXNlcm5hbWVdPy5jb21tZW50c1tjb21tZW50SWRdO1xuICAgIH1cbiAgICBcbiAgICBnZXRVc2VyU2NvcmUodXNlcm5hbWUpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudXNlckRhdGFbdXNlcm5hbWVdPy5zY29yZSB8fCAwO1xuICAgIH1cbiAgICBcbiAgICB1cGRhdGVVc2VyRGlzcGxheSh1c2VybmFtZSkge1xuICAgICAgICAvLyBGaW5kIGFsbCBpbnN0YW5jZXMgb2YgdGhpcyB1c2VybmFtZSBhbmQgdXBkYXRlIHRoZWlyIGRpc3BsYXlzXG4gICAgICAgIGNvbnN0IHVzZXJFbGVtZW50cyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoYGFbaHJlZio9XCIvdXNlci8ke3VzZXJuYW1lfVwiXSwgYVtocmVmKj1cIi91LyR7dXNlcm5hbWV9XCJdYCk7XG4gICAgICAgIHVzZXJFbGVtZW50cy5mb3JFYWNoKGVsZW1lbnQgPT4gdGhpcy5hZGRTY29yZVRvRWxlbWVudChlbGVtZW50LCB1c2VybmFtZSkpO1xuICAgICAgICBcbiAgICAgICAgLy8gQWxzbyBsb29rIGZvciBhdXRob3IgZWxlbWVudHMgd2l0aG91dCBsaW5rcyAob2xkIFJlZGRpdClcbiAgICAgICAgY29uc3QgYXV0aG9yRWxlbWVudHMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuYXV0aG9yJyk7XG4gICAgICAgIGF1dGhvckVsZW1lbnRzLmZvckVhY2goZWxlbWVudCA9PiB7XG4gICAgICAgICAgICBpZiAoZWxlbWVudC50ZXh0Q29udGVudD8udHJpbSgpID09PSB1c2VybmFtZSkge1xuICAgICAgICAgICAgICAgIHRoaXMuYWRkU2NvcmVUb0VsZW1lbnQoZWxlbWVudCwgdXNlcm5hbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG4gICAgXG4gICAgYWRkU2NvcmVUb0VsZW1lbnQoZWxlbWVudCwgdXNlcm5hbWUpIHtcbiAgICAgICAgLy8gQ2hlY2sgaWYgdXNlciBzY29yZXMgc2hvdWxkIGJlIGRpc3BsYXllZFxuICAgICAgICBpZiAoIWN1cnJlbnRTZXR0aW5ncy5zaG93VXNlclNjb3Jlcykge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICAvLyBBdm9pZCBhZGRpbmcgbXVsdGlwbGUgc2NvcmUgYmFkZ2VzXG4gICAgICAgIGlmIChlbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy51c2VyLXNjb3JlLWJhZGdlJykpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgY29uc3QgdXNlckRhdGEgPSB0aGlzLnVzZXJEYXRhW3VzZXJuYW1lXTtcbiAgICAgICAgaWYgKCF1c2VyRGF0YSB8fCAhdXNlckRhdGEuY29tbWVudHMpIHJldHVybjtcbiAgICAgICAgXG4gICAgICAgIGNvbnN0IGNvbW1lbnRzID0gT2JqZWN0LnZhbHVlcyh1c2VyRGF0YS5jb21tZW50cyk7XG4gICAgICAgIGNvbnN0IHRvdGFsQ29tbWVudHMgPSBjb21tZW50cy5sZW5ndGg7XG4gICAgICAgIGNvbnN0IGFpQ29tbWVudHMgPSBjb21tZW50cy5maWx0ZXIoY29tbWVudCA9PiBjb21tZW50LmlzQUkpLmxlbmd0aDtcbiAgICAgICAgXG4gICAgICAgIGlmICh0b3RhbENvbW1lbnRzID09PSAwKSByZXR1cm47IC8vIERvbid0IHNob3cgaWYgbm8gY29tbWVudHMgYW5hbHl6ZWRcbiAgICAgICAgXG4gICAgICAgIGNvbnN0IGFpUGVyY2VudGFnZSA9IE1hdGgucm91bmQoKGFpQ29tbWVudHMgLyB0b3RhbENvbW1lbnRzKSAqIDEwMCk7XG4gICAgICAgIFxuICAgICAgICAvLyBDb2xvciBjb2RpbmcgYmFzZWQgb24gQUkgcGVyY2VudGFnZVxuICAgICAgICBsZXQgYmFja2dyb3VuZENvbG9yLCB0ZXh0Q29sb3I7XG4gICAgICAgIGlmIChhaVBlcmNlbnRhZ2UgPCAyMCkge1xuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yID0gJ3JnYmEoNzYsIDE3NSwgODAsIDAuOCknOyAvLyBHcmVlblxuICAgICAgICAgICAgdGV4dENvbG9yID0gJ3doaXRlJztcbiAgICAgICAgfSBlbHNlIGlmIChhaVBlcmNlbnRhZ2UgPD0gNDApIHtcbiAgICAgICAgICAgIGJhY2tncm91bmRDb2xvciA9ICdyZ2JhKDI1NSwgMTUyLCAwLCAwLjgpJzsgLy8gT3JhbmdlL1llbGxvd1xuICAgICAgICAgICAgdGV4dENvbG9yID0gJ3doaXRlJztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGJhY2tncm91bmRDb2xvciA9ICdyZ2JhKDI0NCwgNjcsIDU0LCAwLjgpJzsgLy8gUmVkXG4gICAgICAgICAgICB0ZXh0Q29sb3IgPSAnd2hpdGUnO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBjb25zdCBiYWRnZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICAgICAgYmFkZ2UuY2xhc3NOYW1lID0gJ3VzZXItc2NvcmUtYmFkZ2UnO1xuICAgICAgICBiYWRnZS5zdHlsZS5jc3NUZXh0ID0gYFxuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDRweDtcbiAgICAgICAgICAgIHBhZGRpbmc6IDFweCA0cHg7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA0cHg7XG4gICAgICAgICAgICBmb250LXNpemU6IDlweDtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgICAgICBmb250LWZhbWlseTogLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCAnU2Vnb2UgVUknLCBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gICAgICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgICAgICAgICAgb3BhY2l0eTogMC43O1xuICAgICAgICAgICAgYmFja2dyb3VuZDogJHtiYWNrZ3JvdW5kQ29sb3J9O1xuICAgICAgICAgICAgY29sb3I6ICR7dGV4dENvbG9yfTtcbiAgICAgICAgYDtcbiAgICAgICAgXG4gICAgICAgIGJhZGdlLnRleHRDb250ZW50ID0gYEFJOiAke2FpUGVyY2VudGFnZX0lICgke2FpQ29tbWVudHN9LyR7dG90YWxDb21tZW50c30pYDtcbiAgICAgICAgXG4gICAgICAgIGxldCByaXNrTGV2ZWw7XG4gICAgICAgIGlmIChhaVBlcmNlbnRhZ2UgPCAyMCkge1xuICAgICAgICAgICAgcmlza0xldmVsID0gJ0xvdyBSaXNrJztcbiAgICAgICAgfSBlbHNlIGlmIChhaVBlcmNlbnRhZ2UgPD0gNDApIHtcbiAgICAgICAgICAgIHJpc2tMZXZlbCA9ICdNZWRpdW0gUmlzayc7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByaXNrTGV2ZWwgPSAnSGlnaCBSaXNrJztcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgYmFkZ2UudGl0bGUgPSBgQUkgRGV0ZWN0aW9uOiAke3Jpc2tMZXZlbH0gLSAke2FpUGVyY2VudGFnZX0lIG9mIGNvbW1lbnRzIGZsYWdnZWQgYXMgQUkgKCR7YWlDb21tZW50c30vJHt0b3RhbENvbW1lbnRzfSBjb21tZW50cylgO1xuICAgICAgICBcbiAgICAgICAgZWxlbWVudC5hcHBlbmRDaGlsZChiYWRnZSk7XG4gICAgfVxuICAgIFxuICAgIC8vIFVwZGF0ZSBhbGwgdmlzaWJsZSB1c2VybmFtZXMgd2l0aCBzY29yZXNcbiAgICB1cGRhdGVBbGxVc2VyRGlzcGxheXMoKSB7XG4gICAgICAgIC8vIEZpbmQgYWxsIHVzZXJuYW1lIGxpbmtzXG4gICAgICAgIGNvbnN0IHVzZXJMaW5rcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ2FbaHJlZio9XCIvdXNlci9cIl0sIGFbaHJlZio9XCIvdS9cIl0nKTtcbiAgICAgICAgdXNlckxpbmtzLmZvckVhY2gobGluayA9PiB7XG4gICAgICAgICAgICBjb25zdCBocmVmID0gbGluay5nZXRBdHRyaWJ1dGUoJ2hyZWYnKTtcbiAgICAgICAgICAgIGNvbnN0IHVzZXJuYW1lID0gaHJlZi5tYXRjaCgvXFwvdSg/OnNlcik/XFwvKFteXFwvXFw/XFwjXSspLyk/LlsxXTtcbiAgICAgICAgICAgIGlmICh1c2VybmFtZSAmJiB0aGlzLnVzZXJEYXRhW3VzZXJuYW1lXSkge1xuICAgICAgICAgICAgICAgIHRoaXMuYWRkU2NvcmVUb0VsZW1lbnQobGluaywgdXNlcm5hbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgXG4gICAgICAgIC8vIEZpbmQgYWxsIGF1dGhvciBlbGVtZW50cyAob2xkIFJlZGRpdClcbiAgICAgICAgY29uc3QgYXV0aG9yRWxlbWVudHMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuYXV0aG9yJyk7XG4gICAgICAgIGF1dGhvckVsZW1lbnRzLmZvckVhY2goZWxlbWVudCA9PiB7XG4gICAgICAgICAgICBjb25zdCB1c2VybmFtZSA9IGVsZW1lbnQudGV4dENvbnRlbnQ/LnRyaW0oKTtcbiAgICAgICAgICAgIGlmICh1c2VybmFtZSAmJiB0aGlzLnVzZXJEYXRhW3VzZXJuYW1lXSAmJiB1c2VybmFtZSAhPT0gJ1tkZWxldGVkXScpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmFkZFNjb3JlVG9FbGVtZW50KGVsZW1lbnQsIHVzZXJuYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIFxuICAgICAgICAvLyBGaW5kIGVsZW1lbnRzIHdpdGggYXV0aG9yLW5hbWUgYXR0cmlidXRlIChuZXcgUmVkZGl0KVxuICAgICAgICBjb25zdCBhdXRob3JOYW1lRWxlbWVudHMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdbYXV0aG9yLW5hbWVdJyk7XG4gICAgICAgIGF1dGhvck5hbWVFbGVtZW50cy5mb3JFYWNoKGVsZW1lbnQgPT4ge1xuICAgICAgICAgICAgY29uc3QgdXNlcm5hbWUgPSBlbGVtZW50LmdldEF0dHJpYnV0ZSgnYXV0aG9yLW5hbWUnKTtcbiAgICAgICAgICAgIGlmICh1c2VybmFtZSAmJiB0aGlzLnVzZXJEYXRhW3VzZXJuYW1lXSAmJiB1c2VybmFtZSAhPT0gJ1tkZWxldGVkXScpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmFkZFNjb3JlVG9FbGVtZW50KGVsZW1lbnQsIHVzZXJuYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxufVxuXG4vLyBJbml0aWFsaXplIHVzZXIgc2NvcmUgbWFuYWdlclxuY29uc3QgdXNlclNjb3JlTWFuYWdlciA9IG5ldyBVc2VyU2NvcmVNYW5hZ2VyKCk7XG5cbi8vIFByb2dyZXNzIHRyYWNraW5nXG5sZXQgcHJvZ3Jlc3NXaWRnZXQgPSBudWxsO1xubGV0IHRvdGFsQ29tbWVudHMgPSAwO1xubGV0IHByb2Nlc3NlZENvdW50ID0gMDtcblxuLy8gQ3JlYXRlIGZsb2F0aW5nIHByb2dyZXNzIHdpZGdldFxuZnVuY3Rpb24gY3JlYXRlUHJvZ3Jlc3NXaWRnZXQoKSB7XG4gICAgLy8gQ2hlY2sgaWYgcHJvZ3Jlc3Mgd2lkZ2V0IHNob3VsZCBiZSBkaXNwbGF5ZWRcbiAgICBpZiAoIWN1cnJlbnRTZXR0aW5ncy5zaG93UHJvZ3Jlc3MpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGNvbnN0IHdpZGdldCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHdpZGdldC5pZCA9ICdsbG0tZGV0ZWN0b3ItcHJvZ3Jlc3MnO1xuICAgIHdpZGdldC5zdHlsZS5jc3NUZXh0ID0gYFxuICAgICAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgICAgIGJvdHRvbTogMjBweDtcbiAgICAgICAgcmlnaHQ6IDIwcHg7XG4gICAgICAgIHdpZHRoOiAzMDBweDtcbiAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDEzNWRlZywgIzY2N2VlYSAwJSwgIzc2NGJhMiAxMDAlKTtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTJweDtcbiAgICAgICAgYm94LXNoYWRvdzogMCA4cHggMzJweCByZ2JhKDAsIDAsIDAsIDAuMyk7XG4gICAgICAgIHBhZGRpbmc6IDE2cHg7XG4gICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgZm9udC1mYW1pbHk6IC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgJ1NlZ29lIFVJJywgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgIHotaW5kZXg6IDEwMDAwO1xuICAgICAgICBiYWNrZHJvcC1maWx0ZXI6IGJsdXIoMTBweCk7XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoMjU1LCAyNTUsIDI1NSwgMC4yKTtcbiAgICAgICAgdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZTtcbiAgICAgICAgYW5pbWF0aW9uOiBzbGlkZUluIDAuM3MgZWFzZS1vdXQ7XG4gICAgYDtcbiAgICBcbiAgICB3aWRnZXQuaW5uZXJIVE1MID0gYFxuICAgICAgICA8ZGl2IHN0eWxlPVwiZGlzcGxheTogZmxleDsganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuOyBhbGlnbi1pdGVtczogY2VudGVyOyBtYXJnaW4tYm90dG9tOiAxMnB4O1wiPlxuICAgICAgICAgICAgPGRpdiBzdHlsZT1cImRpc3BsYXk6IGZsZXg7IGFsaWduLWl0ZW1zOiBjZW50ZXI7IGdhcDogOHB4O1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJ3aWR0aDogMTZweDsgaGVpZ2h0OiAxNnB4OyBiYWNrZ3JvdW5kOiAjZmY5ODAwOyBib3JkZXItcmFkaXVzOiA1MCU7IGRpc3BsYXk6IGZsZXg7IGFsaWduLWl0ZW1zOiBjZW50ZXI7IGp1c3RpZnktY29udGVudDogY2VudGVyOyBmb250LXNpemU6IDEycHg7XCI+8J+kljwvZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPVwiZm9udC13ZWlnaHQ6IDYwMDsgZm9udC1zaXplOiAxM3B4O1wiPkFJIENvbW1lbnQgRGV0ZWN0b3I8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxidXR0b24gaWQ9XCJjbG9zZS1wcm9ncmVzc1wiIHN0eWxlPVwiYmFja2dyb3VuZDogbm9uZTsgYm9yZGVyOiBub25lOyBjb2xvcjogcmdiYSgyNTUsMjU1LDI1NSwwLjcpOyBjdXJzb3I6IHBvaW50ZXI7IGZvbnQtc2l6ZTogMThweDsgbGluZS1oZWlnaHQ6IDE7IHBhZGRpbmc6IDA7IHdpZHRoOiAyMHB4OyBoZWlnaHQ6IDIwcHg7IGRpc3BsYXk6IGZsZXg7IGFsaWduLWl0ZW1zOiBjZW50ZXI7IGp1c3RpZnktY29udGVudDogY2VudGVyOyBib3JkZXItcmFkaXVzOiA0cHg7IHRyYW5zaXRpb246IGFsbCAwLjJzO1wiPsOXPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IHN0eWxlPVwibWFyZ2luLWJvdHRvbTogOHB4O1wiPlxuICAgICAgICAgICAgPGRpdiBpZD1cInByb2dyZXNzLXRleHRcIiBzdHlsZT1cImZvbnQtc2l6ZTogMTJweDsgY29sb3I6IHJnYmEoMjU1LDI1NSwyNTUsMC45KTsgbWFyZ2luLWJvdHRvbTogNnB4O1wiPlNjYW5uaW5nIGNvbW1lbnRzLi4uPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPVwiYmFja2dyb3VuZDogcmdiYSgyNTUsMjU1LDI1NSwwLjIpOyBib3JkZXItcmFkaXVzOiA4cHg7IGhlaWdodDogNnB4OyBvdmVyZmxvdzogaGlkZGVuO1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgaWQ9XCJwcm9ncmVzcy1iYXJcIiBzdHlsZT1cImJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgIzAwZjJmZSAwJSwgIzRmYWNmZSAxMDAlKTsgaGVpZ2h0OiAxMDAlOyB3aWR0aDogMCU7IHRyYW5zaXRpb246IHdpZHRoIDAuM3MgZWFzZTsgYm9yZGVyLXJhZGl1czogOHB4O1wiPjwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGlkPVwic3RhdHVzLXRleHRcIiBzdHlsZT1cImZvbnQtc2l6ZTogMTFweDsgY29sb3I6IHJnYmEoMjU1LDI1NSwyNTUsMC43KTtcIj5Jbml0aWFsaXppbmcuLi48L2Rpdj5cbiAgICBgO1xuICAgIFxuICAgIC8vIEFkZCBzbGlkZS1pbiBhbmltYXRpb25cbiAgICBjb25zdCBzdHlsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJyk7XG4gICAgc3R5bGUudGV4dENvbnRlbnQgPSBgXG4gICAgICAgIEBrZXlmcmFtZXMgc2xpZGVJbiB7XG4gICAgICAgICAgICBmcm9tIHsgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKDEwMCUpOyBvcGFjaXR5OiAwOyB9XG4gICAgICAgICAgICB0byB7IHRyYW5zZm9ybTogdHJhbnNsYXRlWCgwKTsgb3BhY2l0eTogMTsgfVxuICAgICAgICB9XG4gICAgICAgICNsbG0tZGV0ZWN0b3ItcHJvZ3Jlc3M6aG92ZXIge1xuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0ycHgpO1xuICAgICAgICAgICAgYm94LXNoYWRvdzogMCAxMnB4IDQwcHggcmdiYSgwLCAwLCAwLCAwLjQpO1xuICAgICAgICB9XG4gICAgICAgICNjbG9zZS1wcm9ncmVzczpob3ZlciB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwyNTUsMjU1LDAuMikgIWltcG9ydGFudDtcbiAgICAgICAgICAgIGNvbG9yOiB3aGl0ZSAhaW1wb3J0YW50O1xuICAgICAgICB9XG4gICAgYDtcbiAgICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKHN0eWxlKTtcbiAgICBcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHdpZGdldCk7XG4gICAgXG4gICAgLy8gQWRkIGNsb3NlIGZ1bmN0aW9uYWxpdHlcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnY2xvc2UtcHJvZ3Jlc3MnKS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICAgICAgd2lkZ2V0LnN0eWxlLmFuaW1hdGlvbiA9ICdzbGlkZU91dCAwLjNzIGVhc2UtaW4gZm9yd2FyZHMnO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHdpZGdldC5yZW1vdmUoKSwgMzAwKTtcbiAgICB9KTtcbiAgICBcbiAgICAvLyBBZGQgc2xpZGUtb3V0IGFuaW1hdGlvblxuICAgIHN0eWxlLnRleHRDb250ZW50ICs9IGBcbiAgICAgICAgQGtleWZyYW1lcyBzbGlkZU91dCB7XG4gICAgICAgICAgICBmcm9tIHsgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKDApOyBvcGFjaXR5OiAxOyB9XG4gICAgICAgICAgICB0byB7IHRyYW5zZm9ybTogdHJhbnNsYXRlWCgxMDAlKTsgb3BhY2l0eTogMDsgfVxuICAgICAgICB9XG4gICAgYDtcbiAgICBcbiAgICByZXR1cm4gd2lkZ2V0O1xufVxuXG4vLyBVcGRhdGUgcHJvZ3Jlc3Mgd2lkZ2V0XG5mdW5jdGlvbiB1cGRhdGVQcm9ncmVzcyhwcm9jZXNzZWQsIHRvdGFsLCBzdGF0dXMgPSAnJykge1xuICAgIC8vIENoZWNrIGlmIHByb2dyZXNzIHNob3VsZCBiZSBzaG93blxuICAgIGlmICghY3VycmVudFNldHRpbmdzLnNob3dQcm9ncmVzcykge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIFxuICAgIC8vIENoZWNrIGlmIHdpZGdldCBzdGlsbCBleGlzdHMgYW5kIHJlY3JlYXRlIGlmIG5lZWRlZFxuICAgIGlmICghcHJvZ3Jlc3NXaWRnZXQgfHwgIWRvY3VtZW50LmJvZHkuY29udGFpbnMocHJvZ3Jlc3NXaWRnZXQpKSB7XG4gICAgICAgIGlmIChwcm9ncmVzc1dpZGdldCkge1xuICAgICAgICAgICAgcHJvZ3Jlc3NXaWRnZXQucmVtb3ZlKCk7XG4gICAgICAgIH1cbiAgICAgICAgcHJvZ3Jlc3NXaWRnZXQgPSBjcmVhdGVQcm9ncmVzc1dpZGdldCgpO1xuICAgIH1cbiAgICBcbiAgICAvLyBJZiBwcm9ncmVzc1dpZGdldCBpcyBudWxsIChzZXR0aW5ncyBkaXNhYmxlZCksIHJldHVybiBlYXJseVxuICAgIGlmICghcHJvZ3Jlc3NXaWRnZXQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBcbiAgICBjb25zdCBwcm9ncmVzc0JhciA9IHByb2dyZXNzV2lkZ2V0LnF1ZXJ5U2VsZWN0b3IoJyNwcm9ncmVzcy1iYXInKTtcbiAgICBjb25zdCBwcm9ncmVzc1RleHQgPSBwcm9ncmVzc1dpZGdldC5xdWVyeVNlbGVjdG9yKCcjcHJvZ3Jlc3MtdGV4dCcpO1xuICAgIGNvbnN0IHN0YXR1c1RleHQgPSBwcm9ncmVzc1dpZGdldC5xdWVyeVNlbGVjdG9yKCcjc3RhdHVzLXRleHQnKTtcbiAgICBcbiAgICBjb25zdCBwZXJjZW50YWdlID0gdG90YWwgPiAwID8gTWF0aC5yb3VuZCgocHJvY2Vzc2VkIC8gdG90YWwpICogMTAwKSA6IDA7XG4gICAgXG4gICAgaWYgKHByb2dyZXNzQmFyKSB7XG4gICAgICAgIHByb2dyZXNzQmFyLnN0eWxlLndpZHRoID0gYCR7cGVyY2VudGFnZX0lYDtcbiAgICB9XG4gICAgXG4gICAgaWYgKHByb2dyZXNzVGV4dCkge1xuICAgICAgICBwcm9ncmVzc1RleHQudGV4dENvbnRlbnQgPSBgQW5hbHl6aW5nIGNvbW1lbnRzOiAke3Byb2Nlc3NlZH0vJHt0b3RhbH0gKCR7cGVyY2VudGFnZX0lKWA7XG4gICAgfVxuICAgIFxuICAgIGlmIChzdGF0dXNUZXh0KSB7XG4gICAgICAgIHN0YXR1c1RleHQudGV4dENvbnRlbnQgPSBzdGF0dXMgfHwgYCR7cHJvY2Vzc2VkfSBjb21tZW50cyBwcm9jZXNzZWRgO1xuICAgIH1cbiAgICBcbiAgICAvLyBBdXRvLWhpZGUgd2hlbiBjb21wbGV0ZVxuICAgIGlmIChwcm9jZXNzZWQgPj0gdG90YWwgJiYgdG90YWwgPiAwKSB7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgaWYgKHByb2dyZXNzV2lkZ2V0ICYmIHByb2dyZXNzV2lkZ2V0LnBhcmVudE5vZGUpIHtcbiAgICAgICAgICAgICAgICBwcm9ncmVzc1dpZGdldC5zdHlsZS5hbmltYXRpb24gPSAnc2xpZGVPdXQgMC4zcyBlYXNlLWluIGZvcndhcmRzJztcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb2dyZXNzV2lkZ2V0ICYmIHByb2dyZXNzV2lkZ2V0LnBhcmVudE5vZGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb2dyZXNzV2lkZ2V0LnJlbW92ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcHJvZ3Jlc3NXaWRnZXQgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSwgMzAwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgMjAwMCk7XG4gICAgfVxufVxuXG4vLyBGdW5jdGlvbiB0byBkZXRlY3QgUmVkZGl0IHZhcmlhbnRcbmZ1bmN0aW9uIGRldGVjdFJlZGRpdFZhcmlhbnQoKSB7XG4gICAgY29uc3QgaG9zdG5hbWUgPSB3aW5kb3cubG9jYXRpb24uaG9zdG5hbWU7XG4gICAgaWYgKGhvc3RuYW1lLmluY2x1ZGVzKCdvbGQucmVkZGl0JykpIHJldHVybiAnb2xkUmVkZGl0JztcbiAgICBpZiAoaG9zdG5hbWUuaW5jbHVkZXMoJ3NoLnJlZGRpdCcpKSByZXR1cm4gJ25ld1JlZGRpdCc7IC8vIHNoLnJlZGRpdCB1c2VzIG5ldyByZWRkaXQgVUlcbiAgICBpZiAoaG9zdG5hbWUuaW5jbHVkZXMoJ3JlZGRpdC5jb20nKSkgcmV0dXJuICduZXdSZWRkaXQnO1xuICAgIHJldHVybiAnZ2VuZXJhbCc7XG59XG5cbi8vIEZ1bmN0aW9uIHRvIGdldCBjb21tZW50IHRleHQgY29udGVudFxuZnVuY3Rpb24gZ2V0Q29tbWVudFRleHQoZWxlbWVudCkge1xuICAgIC8vIFJlbW92ZSBhbnkgbmVzdGVkIHF1b3RlcyBvciBvdGhlciBjb21tZW50cyB0byBnZXQganVzdCB0aGUgbWFpbiBjb21tZW50IHRleHRcbiAgICBjb25zdCBjbG9uZSA9IGVsZW1lbnQuY2xvbmVOb2RlKHRydWUpO1xuICAgIFxuICAgIC8vIFJlbW92ZSBxdW90ZWQgdGV4dCBhbmQgb3RoZXIgbmVzdGVkIGVsZW1lbnRzIHRoYXQgYXJlbid0IHBhcnQgb2YgdGhlIG1haW4gY29tbWVudFxuICAgIGNvbnN0IHF1b3RlcyA9IGNsb25lLnF1ZXJ5U2VsZWN0b3JBbGwoJ2Jsb2NrcXVvdGUsIC5tZC1zcG9pbGVyLXRleHQnKTtcbiAgICBxdW90ZXMuZm9yRWFjaChxdW90ZSA9PiBxdW90ZS5yZW1vdmUoKSk7XG4gICAgXG4gICAgcmV0dXJuIGNsb25lLnRleHRDb250ZW50Py50cmltKCkgfHwgJyc7XG59XG5cbi8vIEZ1bmN0aW9uIHRvIGNoZWNrIGlmIG1vZGVsIGlzIHJlYWR5XG5hc3luYyBmdW5jdGlvbiBlbnN1cmVNb2RlbFJlYWR5KCkge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICAvLyBTZW5kIGEgdGVzdCBtZXNzYWdlIHRvIGVuc3VyZSB0aGUgbW9kZWwgaXMgbG9hZGVkXG4gICAgICAgIGNvbnN0IHRlc3RNZXNzYWdlID0ge1xuICAgICAgICAgICAgYWN0aW9uOiAnY2xhc3NpZnknLFxuICAgICAgICAgICAgdGV4dDogJ1Rlc3QgbWVzc2FnZSB0byBpbml0aWFsaXplIG1vZGVsJ1xuICAgICAgICB9O1xuICAgICAgICBcbiAgICAgICAgY29uc29sZS5sb2coJ0NoZWNraW5nIGlmIG1vZGVsIGlzIHJlYWR5Li4uJyk7XG4gICAgICAgIFxuICAgICAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh0ZXN0TWVzc2FnZSwgKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICBpZiAoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignTW9kZWwgcmVhZHkgY2hlY2sgZmFpbGVkOicsIGNocm9tZS5ydW50aW1lLmxhc3RFcnJvcik7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZShmYWxzZSk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHJlc3BvbnNlICYmIHJlc3BvbnNlLmVycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignTW9kZWwgcmVhZHkgY2hlY2sgZXJyb3I6JywgcmVzcG9uc2UuZXJyb3IpO1xuICAgICAgICAgICAgICAgIHJlc29sdmUoZmFsc2UpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnTW9kZWwgaXMgcmVhZHkgZm9yIGNsYXNzaWZpY2F0aW9uJyk7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZSh0cnVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSk7XG59XG5cbi8vIEZ1bmN0aW9uIHRvIGNsYXNzaWZ5IGEgY29tbWVudFxuYXN5bmMgZnVuY3Rpb24gY2xhc3NpZnlDb21tZW50KHRleHQsIHJldHJ5Q291bnQgPSAwKSB7XG4gICAgaWYgKCF0ZXh0IHx8IHRleHQubGVuZ3RoIDwgMTApIHJldHVybiBudWxsOyAvLyBTa2lwIHZlcnkgc2hvcnQgY29tbWVudHNcbiAgICBcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBtZXNzYWdlID0ge1xuICAgICAgICAgICAgYWN0aW9uOiAnY2xhc3NpZnknLFxuICAgICAgICAgICAgdGV4dDogdGV4dFxuICAgICAgICB9O1xuICAgICAgICBcbiAgICAgICAgY29uc29sZS5sb2coJ1NlbmRpbmcgbWVzc2FnZSB0byBiYWNrZ3JvdW5kIHNjcmlwdDonLCBtZXNzYWdlKTtcbiAgICAgICAgXG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICAgICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UobWVzc2FnZSwgKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ1JlY2VpdmVkIHJlc3BvbnNlIGZyb20gYmFja2dyb3VuZCBzY3JpcHQ6JywgcmVzcG9uc2UpO1xuICAgICAgICAgICAgICAgIGlmIChjaHJvbWUucnVudGltZS5sYXN0RXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignQ2hyb21lIHJ1bnRpbWUgZXJyb3I6JywgY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShudWxsKTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKHJlc3BvbnNlICYmIHJlc3BvbnNlLmVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0JhY2tncm91bmQgc2NyaXB0IGVycm9yOicsIHJlc3BvbnNlLmVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIC8vIFJldHJ5IHNlc3Npb24gZXJyb3JzIG9uY2UgYWZ0ZXIgYSBkZWxheVxuICAgICAgICAgICAgICAgICAgICBpZiAoKHJlc3BvbnNlLmVycm9yLmluY2x1ZGVzKCdTZXNzaW9uJykgfHwgcmVzcG9uc2UuZXJyb3IuaW5jbHVkZXMoJ3Nlc3Npb24nKSkgJiYgcmV0cnlDb3VudCA8IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdSZXRyeWluZyBhZnRlciBzZXNzaW9uIGVycm9yLi4uJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc2lmeUNvbW1lbnQodGV4dCwgcmV0cnlDb3VudCArIDEpLnRoZW4ocmVzb2x2ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9LCAzMDAwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShudWxsKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHJlc3BvbnNlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgY2xhc3NpZnlpbmcgY29tbWVudDonLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbn1cblxuLy8gRnVuY3Rpb24gdG8gaGlnaGxpZ2h0IExMTS1kZXRlY3RlZCBjb21tZW50XG5mdW5jdGlvbiBoaWdobGlnaHRMTE1Db21tZW50KGNvbW1lbnRFbGVtZW50KSB7XG4gICAgLy8gQ2hlY2sgaWYgY29tbWVudCBoaWdobGlnaHRpbmcgc2hvdWxkIGJlIHNob3duXG4gICAgaWYgKCFjdXJyZW50U2V0dGluZ3MuaGlnaGxpZ2h0Q29tbWVudHMpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBcbiAgICAvLyBBdm9pZCBoaWdobGlnaHRpbmcgdGhlIHNhbWUgZWxlbWVudCBtdWx0aXBsZSB0aW1lc1xuICAgIGlmIChjb21tZW50RWxlbWVudC5kYXRhc2V0LmxsbUhpZ2hsaWdodGVkKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29tbWVudEVsZW1lbnQuZGF0YXNldC5sbG1IaWdobGlnaHRlZCA9ICd0cnVlJztcbiAgICBcbiAgICAvLyBGaW5kIHRoZSBjbG9zZXN0IGNvbnRhaW5lciAoY29tbWVudCBjb250YWluZXIpXG4gICAgY29uc3QgY29udGFpbmVyID0gY29tbWVudEVsZW1lbnQuY2xvc2VzdCgnc2hyZWRkaXQtcHJvZmlsZS1jb21tZW50LCBzaHJlZGRpdC1jb21tZW50LCBbZGF0YS10ZXN0aWQ9XCJjb21tZW50XCJdLCAuY29tbWVudCcpIHx8IGNvbW1lbnRFbGVtZW50LnBhcmVudEVsZW1lbnQ7XG4gICAgXG4gICAgaWYgKCFjb250YWluZXIpIHJldHVybjtcbiAgICBcbiAgICAvLyBBZGQgbm9uLWRlc3RydWN0aXZlIHN0eWxpbmcgdG8gdGhlIGNvbnRhaW5lclxuICAgIGNvbnRhaW5lci5zdHlsZS5jc3NUZXh0ICs9IGBcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoNDVkZWcsIHJnYmEoMjU1LCAxOTMsIDcsIDAuMDUpLCByZ2JhKDI1NSwgMTUyLCAwLCAwLjA1KSkgIWltcG9ydGFudDtcbiAgICAgICAgYm9yZGVyLWxlZnQ6IDRweCBzb2xpZCAjZmY5ODAwICFpbXBvcnRhbnQ7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDhweCAhaW1wb3J0YW50O1xuICAgICAgICBib3gtc2hhZG93OiAwIDJweCA4cHggcmdiYSgyNTUsIDE1MiwgMCwgMC4yKSAhaW1wb3J0YW50O1xuICAgICAgICBtYXJnaW46IDhweCAwICFpbXBvcnRhbnQ7XG4gICAgYDtcbiAgICBcbiAgICAvLyBDcmVhdGUgd2FybmluZyBiYWRnZSBhcyBmbG9hdGluZyBvdmVybGF5IChub24tZGVzdHJ1Y3RpdmUpXG4gICAgY29uc3Qgd2FybmluZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHdhcm5pbmcuY2xhc3NOYW1lID0gJ2xsbS13YXJuaW5nLWJhZGdlJztcbiAgICB3YXJuaW5nLnN0eWxlLmNzc1RleHQgPSBgXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgYm90dG9tOiAtMTJweDtcbiAgICAgICAgbGVmdDogNTAlO1xuICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTUwJSk7XG4gICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgxMzVkZWcsICNmZjk4MDAsICNmZjZmMDApO1xuICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgIHBhZGRpbmc6IDRweCA4cHg7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEycHg7XG4gICAgICAgIGZvbnQtc2l6ZTogMTFweDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgICAgei1pbmRleDogMTAwMDA7XG4gICAgICAgIGJveC1zaGFkb3c6IDAgMnB4IDZweCByZ2JhKDI1NSwgMTUyLCAwLCAwLjQpO1xuICAgICAgICBib3JkZXI6IDJweCBzb2xpZCB3aGl0ZTtcbiAgICAgICAgZm9udC1mYW1pbHk6IC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgJ1NlZ29lIFVJJywgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgICAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICBgO1xuICAgIHdhcm5pbmcuaW5uZXJIVE1MID0gYOKaoO+4jyBNYXkgYmUgQUktZ2VuZXJhdGVkYDtcbiAgICBcbiAgICAvLyBJbnNlcnQgdGhlIGJhZGdlIHdpdGhvdXQgbW92aW5nIGV4aXN0aW5nIGVsZW1lbnRzIG9yIGFmZmVjdGluZyBsYXlvdXRcbiAgICBjb250YWluZXIuc3R5bGUucG9zaXRpb24gPSAncmVsYXRpdmUnO1xuICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZCh3YXJuaW5nKTtcbn1cblxuLy8gRnVuY3Rpb24gdG8gbWFyayBodW1hbi13cml0dGVuIGNvbW1lbnQgd2l0aCBzbWFsbCBpbmRpY2F0b3JcbmZ1bmN0aW9uIG1hcmtIdW1hbkNvbW1lbnQoY29tbWVudEVsZW1lbnQpIHtcbiAgICAvLyBDaGVjayBpZiBodW1hbiBpbmRpY2F0b3JzIHNob3VsZCBiZSBzaG93blxuICAgIGlmICghY3VycmVudFNldHRpbmdzLnNob3dIdW1hbkluZGljYXRvcnMpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBcbiAgICAvLyBBdm9pZCBtYXJraW5nIHRoZSBzYW1lIGVsZW1lbnQgbXVsdGlwbGUgdGltZXNcbiAgICBpZiAoY29tbWVudEVsZW1lbnQuZGF0YXNldC5odW1hbk1hcmtlZCkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbW1lbnRFbGVtZW50LmRhdGFzZXQuaHVtYW5NYXJrZWQgPSAndHJ1ZSc7XG4gICAgXG4gICAgLy8gRmluZCB0aGUgY2xvc2VzdCBjb250YWluZXIgKGNvbW1lbnQgY29udGFpbmVyKVxuICAgIGNvbnN0IGNvbnRhaW5lciA9IGNvbW1lbnRFbGVtZW50LmNsb3Nlc3QoJ3NocmVkZGl0LXByb2ZpbGUtY29tbWVudCwgc2hyZWRkaXQtY29tbWVudCwgW2RhdGEtdGVzdGlkPVwiY29tbWVudFwiXSwgLmNvbW1lbnQnKSB8fCBjb21tZW50RWxlbWVudC5wYXJlbnRFbGVtZW50O1xuICAgIFxuICAgIGlmICghY29udGFpbmVyKSByZXR1cm47XG4gICAgXG4gICAgLy8gQ3JlYXRlIHNtYWxsIHByb2dyZXNzIGluZGljYXRvciBhcyBmbG9hdGluZyBvdmVybGF5IChub24tZGVzdHJ1Y3RpdmUpXG4gICAgY29uc3QgaW5kaWNhdG9yID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgaW5kaWNhdG9yLmNsYXNzTmFtZSA9ICdodW1hbi1pbmRpY2F0b3InO1xuICAgIGluZGljYXRvci5zdHlsZS5jc3NUZXh0ID0gYFxuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIGJvdHRvbTogLThweDtcbiAgICAgICAgcmlnaHQ6IDhweDtcbiAgICAgICAgYmFja2dyb3VuZDogcmdiYSg3NiwgMTc1LCA4MCwgMC44KTtcbiAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICBwYWRkaW5nOiAycHggNnB4O1xuICAgICAgICBib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgICAgIGZvbnQtc2l6ZTogOXB4O1xuICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICB6LWluZGV4OiA5OTk5O1xuICAgICAgICBib3gtc2hhZG93OiAwIDFweCAzcHggcmdiYSg3NiwgMTc1LCA4MCwgMC4zKTtcbiAgICAgICAgZm9udC1mYW1pbHk6IC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgJ1NlZ29lIFVJJywgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgICAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICAgICAgb3BhY2l0eTogMC42O1xuICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgIGA7XG4gICAgaW5kaWNhdG9yLmlubmVySFRNTCA9IGDinJMgSHVtYW5gO1xuICAgIFxuICAgIC8vIEluc2VydCB0aGUgaW5kaWNhdG9yIHdpdGhvdXQgbW92aW5nIGV4aXN0aW5nIGVsZW1lbnRzIG9yIGFmZmVjdGluZyBsYXlvdXRcbiAgICBjb250YWluZXIuc3R5bGUucG9zaXRpb24gPSAncmVsYXRpdmUnO1xuICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZChpbmRpY2F0b3IpO1xufVxuXG4vLyBGdW5jdGlvbiB0byBtaW5pbWl6ZS9jb2xsYXBzZSBhIGNvbW1lbnQgKGZvciBIaWdoIGFnZ3Jlc3Npb24pXG5mdW5jdGlvbiBtaW5pbWl6ZUNvbW1lbnQoY29tbWVudEVsZW1lbnQpIHtcbiAgICBjb25zb2xlLmxvZygn8J+UjSBNSU5JTUlaRSBERUJVRzogU3RhcnRpbmcgbWluaW1pemVDb21tZW50IGZ1bmN0aW9uJyk7XG4gICAgY29uc29sZS5sb2coJ/CflI0gTUlOSU1JWkUgREVCVUc6IENvbW1lbnQgZWxlbWVudDonLCBjb21tZW50RWxlbWVudCk7XG4gICAgXG4gICAgY29uc3QgY29udGFpbmVyID0gY29tbWVudEVsZW1lbnQuY2xvc2VzdCgnc2hyZWRkaXQtcHJvZmlsZS1jb21tZW50LCBzaHJlZGRpdC1jb21tZW50LCBbZGF0YS10ZXN0aWQ9XCJjb21tZW50XCJdLCAuY29tbWVudCcpO1xuICAgIGNvbnNvbGUubG9nKCfwn5SNIE1JTklNSVpFIERFQlVHOiBGb3VuZCBjb250YWluZXI6JywgY29udGFpbmVyKTtcbiAgICBcbiAgICBpZiAoIWNvbnRhaW5lcikge1xuICAgICAgICBjb25zb2xlLmxvZygn8J+UjSBNSU5JTUlaRSBERUJVRzogTm8gY29udGFpbmVyIGZvdW5kLCByZXR1cm5pbmcgZmFsc2UnKTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBcbiAgICB0cnkge1xuICAgICAgICAvLyBPbGQgUmVkZGl0IC0gbG9vayBmb3IgY29sbGFwc2UvZXhwYW5kIGJ1dHRvblxuICAgICAgICBjb25zb2xlLmxvZygn8J+UjSBNSU5JTUlaRSBERUJVRzogTG9va2luZyBmb3Igb2xkIFJlZGRpdCBleHBhbmQgYnV0dG9uLi4uJyk7XG4gICAgICAgIGNvbnN0IGV4cGFuZEJ1dHRvbiA9IGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCcuZXhwYW5kW29uY2xpY2sqPVwidG9nZ2xlY29tbWVudFwiXScpO1xuICAgICAgICBjb25zb2xlLmxvZygn8J+UjSBNSU5JTUlaRSBERUJVRzogT2xkIFJlZGRpdCBleHBhbmQgYnV0dG9uIGZvdW5kOicsIGV4cGFuZEJ1dHRvbik7XG4gICAgICAgIFxuICAgICAgICBpZiAoZXhwYW5kQnV0dG9uKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygn8J+UjSBNSU5JTUlaRSBERUJVRzogQ2xpY2tpbmcgb2xkIFJlZGRpdCBleHBhbmQgYnV0dG9uJyk7XG4gICAgICAgICAgICBleHBhbmRCdXR0b24uY2xpY2soKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCfinIUgTUlOSU1JWkUgU1VDQ0VTUzogTWluaW1pemVkIGNvbW1lbnQgdXNpbmcgb2xkIFJlZGRpdCBleHBhbmQgYnV0dG9uJyk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgLy8gVHJ5IGFsdGVybmF0aXZlIG9sZCBSZWRkaXQgc2VsZWN0b3JzXG4gICAgICAgIGNvbnNvbGUubG9nKCfwn5SNIE1JTklNSVpFIERFQlVHOiBUcnlpbmcgYWx0ZXJuYXRpdmUgb2xkIFJlZGRpdCBzZWxlY3RvcnMuLi4nKTtcbiAgICAgICAgY29uc3QgYWx0RXhwYW5kQnV0dG9uID0gY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJy5leHBhbmQsIGFbb25jbGljayo9XCJ0b2dnbGVjb21tZW50XCJdLCBbb25jbGljayo9XCJjb2xsYXBzZVwiXScpO1xuICAgICAgICBjb25zb2xlLmxvZygn8J+UjSBNSU5JTUlaRSBERUJVRzogQWx0ZXJuYXRpdmUgZXhwYW5kIGJ1dHRvbiBmb3VuZDonLCBhbHRFeHBhbmRCdXR0b24pO1xuICAgICAgICBcbiAgICAgICAgaWYgKGFsdEV4cGFuZEJ1dHRvbikge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ/CflI0gTUlOSU1JWkUgREVCVUc6IENsaWNraW5nIGFsdGVybmF0aXZlIGV4cGFuZCBidXR0b24nKTtcbiAgICAgICAgICAgIGFsdEV4cGFuZEJ1dHRvbi5jbGljaygpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ+KchSBNSU5JTUlaRSBTVUNDRVNTOiBNaW5pbWl6ZWQgY29tbWVudCB1c2luZyBhbHRlcm5hdGl2ZSBleHBhbmQgYnV0dG9uJyk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgLy8gTmV3IFJlZGRpdCAtIGxvb2sgZm9yIGNvbGxhcHNlIGJ1dHRvblxuICAgICAgICBjb25zb2xlLmxvZygn8J+UjSBNSU5JTUlaRSBERUJVRzogTG9va2luZyBmb3IgbmV3IFJlZGRpdCBjb2xsYXBzZSBidXR0b24uLi4nKTtcbiAgICAgICAgY29uc3QgY29sbGFwc2VCdXR0b24gPSBjb250YWluZXIucXVlcnlTZWxlY3RvcignYnV0dG9uW2FyaWEtbGFiZWwqPVwiY29sbGFwc2VcIl0sIGJ1dHRvblthcmlhLWxhYmVsKj1cIkNvbGxhcHNlXCJdJyk7XG4gICAgICAgIGNvbnNvbGUubG9nKCfwn5SNIE1JTklNSVpFIERFQlVHOiBOZXcgUmVkZGl0IGNvbGxhcHNlIGJ1dHRvbiBmb3VuZDonLCBjb2xsYXBzZUJ1dHRvbik7XG4gICAgICAgIFxuICAgICAgICBpZiAoY29sbGFwc2VCdXR0b24pIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCfwn5SNIE1JTklNSVpFIERFQlVHOiBDbGlja2luZyBuZXcgUmVkZGl0IGNvbGxhcHNlIGJ1dHRvbicpO1xuICAgICAgICAgICAgY29sbGFwc2VCdXR0b24uY2xpY2soKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCfinIUgTUlOSU1JWkUgU1VDQ0VTUzogTWluaW1pemVkIGNvbW1lbnQgdXNpbmcgbmV3IFJlZGRpdCBjb2xsYXBzZSBidXR0b24nKTtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICAvLyBUcnkgbW9yZSBuZXcgUmVkZGl0IHNlbGVjdG9yc1xuICAgICAgICBjb25zb2xlLmxvZygn8J+UjSBNSU5JTUlaRSBERUJVRzogVHJ5aW5nIG1vcmUgbmV3IFJlZGRpdCBzZWxlY3RvcnMuLi4nKTtcbiAgICAgICAgY29uc3QgbW9yZUNvbGxhcHNlQnV0dG9ucyA9IGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yQWxsKCdidXR0b25bZGF0YS10ZXN0aWQqPVwiY29sbGFwc2VcIl0sIGJ1dHRvblt0aXRsZSo9XCJjb2xsYXBzZVwiXSwgYnV0dG9uW3RpdGxlKj1cIkNvbGxhcHNlXCJdJyk7XG4gICAgICAgIGNvbnNvbGUubG9nKCfwn5SNIE1JTklNSVpFIERFQlVHOiBBZGRpdGlvbmFsIGNvbGxhcHNlIGJ1dHRvbnMgZm91bmQ6JywgbW9yZUNvbGxhcHNlQnV0dG9ucyk7XG4gICAgICAgIFxuICAgICAgICBpZiAobW9yZUNvbGxhcHNlQnV0dG9ucy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygn8J+UjSBNSU5JTUlaRSBERUJVRzogQ2xpY2tpbmcgZmlyc3QgYWRkaXRpb25hbCBjb2xsYXBzZSBidXR0b24nKTtcbiAgICAgICAgICAgIG1vcmVDb2xsYXBzZUJ1dHRvbnNbMF0uY2xpY2soKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCfinIUgTUlOSU1JWkUgU1VDQ0VTUzogTWluaW1pemVkIGNvbW1lbnQgdXNpbmcgYWRkaXRpb25hbCBjb2xsYXBzZSBidXR0b24nKTtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICAvLyBGYWxsYmFjayAtIGhpZGUgdGhlIGNvbW1lbnQgYm9keSBtYW51YWxseVxuICAgICAgICBjb25zb2xlLmxvZygn8J+UjSBNSU5JTUlaRSBERUJVRzogTm8gbmF0aXZlIGJ1dHRvbnMgZm91bmQsIHRyeWluZyBmYWxsYmFjayBtZXRob2QuLi4nKTtcbiAgICAgICAgY29uc3QgY29tbWVudEJvZHkgPSBjb250YWluZXIucXVlcnlTZWxlY3RvcignLnVzZXJ0ZXh0LWJvZHksIC5tZCwgW2RhdGEtdGVzdGlkPVwiY29tbWVudC1jb250ZW50XCJdJyk7XG4gICAgICAgIGNvbnNvbGUubG9nKCfwn5SNIE1JTklNSVpFIERFQlVHOiBDb21tZW50IGJvZHkgZm91bmQgZm9yIGZhbGxiYWNrOicsIGNvbW1lbnRCb2R5KTtcbiAgICAgICAgXG4gICAgICAgIGlmIChjb21tZW50Qm9keSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ/CflI0gTUlOSU1JWkUgREVCVUc6IEhpZGluZyBjb21tZW50IGJvZHkgbWFudWFsbHknKTtcbiAgICAgICAgICAgIGNvbW1lbnRCb2R5LnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIC8vIEFkZCBhIHNtYWxsIGluZGljYXRvciB0aGF0IHRoZSBjb21tZW50IHdhcyBhdXRvLW1pbmltaXplZFxuICAgICAgICAgICAgY29uc3QgaW5kaWNhdG9yID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgICAgICAgICBpbmRpY2F0b3IuY2xhc3NOYW1lID0gJ2F1dG8tbWluaW1pemVkLWluZGljYXRvcic7XG4gICAgICAgICAgICBpbmRpY2F0b3Iuc3R5bGUuY3NzVGV4dCA9IGBcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDExcHg7XG4gICAgICAgICAgICAgICAgY29sb3I6ICNmZjk4MDA7XG4gICAgICAgICAgICAgICAgZm9udC1zdHlsZTogaXRhbGljO1xuICAgICAgICAgICAgICAgIG1hcmdpbjogNHB4IDA7XG4gICAgICAgICAgICAgICAgcGFkZGluZzogMnB4IDRweDtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwgMTUyLCAwLCAwLjEpO1xuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICAgICAgYDtcbiAgICAgICAgICAgIGluZGljYXRvci50ZXh0Q29udGVudCA9ICfwn6SWIEF1dG8tbWluaW1pemVkIChzdXNwZWN0ZWQgQUkpIC0gQ2xpY2sgdG8gZXhwYW5kJztcbiAgICAgICAgICAgIGluZGljYXRvci5vbmNsaWNrID0gKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCfwn5SNIE1JTklNSVpFIERFQlVHOiBVc2VyIGNsaWNrZWQgdG8gZXhwYW5kIGNvbW1lbnQnKTtcbiAgICAgICAgICAgICAgICBjb21tZW50Qm9keS5zdHlsZS5kaXNwbGF5ID0gJyc7XG4gICAgICAgICAgICAgICAgaW5kaWNhdG9yLnJlbW92ZSgpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgY29tbWVudEJvZHkucGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUoaW5kaWNhdG9yLCBjb21tZW50Qm9keSk7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygn4pyFIE1JTklNSVpFIFNVQ0NFU1M6IE1hbnVhbGx5IG1pbmltaXplZCBjb21tZW50IHdpdGggZmFsbGJhY2sgbWV0aG9kJyk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgY29uc29sZS5sb2coJ+KdjCBNSU5JTUlaRSBGQUlMRUQ6IE5vIGNvbW1lbnQgYm9keSBmb3VuZCBmb3IgZmFsbGJhY2snKTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ+KdjCBNSU5JTUlaRSBFUlJPUjogRXJyb3IgbWluaW1pemluZyBjb21tZW50OicsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbn1cblxuLy8gRnVuY3Rpb24gdG8gYXBwbHkgYWdncmVzc2lvbi1iYXNlZCBhY3Rpb25zIHRvIEFJLWRldGVjdGVkIGNvbW1lbnRzXG5mdW5jdGlvbiBhcHBseUFnZ3Jlc3Npb25BY3Rpb25zKGNvbW1lbnRFbGVtZW50KSB7XG4gICAgY29uc29sZS5sb2coJ/CflI0gQUdHUkVTU0lPTiBERUJVRzogQXBwbHlpbmcgYWdncmVzc2lvbiBhY3Rpb25zJyk7XG4gICAgY29uc29sZS5sb2coJ/CflI0gQUdHUkVTU0lPTiBERUJVRzogQ3VycmVudCBzZXR0aW5ncyBvYmplY3Q6JywgY3VycmVudFNldHRpbmdzKTtcbiAgICBjb25zb2xlLmxvZygn8J+UjSBBR0dSRVNTSU9OIERFQlVHOiBBZ2dyZXNzaW9uIGxldmVsOicsIGN1cnJlbnRTZXR0aW5ncy5hZ2dyZXNzaW9uTGV2ZWwpO1xuICAgIGNvbnNvbGUubG9nKCfwn5SNIEFHR1JFU1NJT04gREVCVUc6IEFnZ3Jlc3Npb24gbGV2ZWwgdHlwZTonLCB0eXBlb2YgY3VycmVudFNldHRpbmdzLmFnZ3Jlc3Npb25MZXZlbCk7XG4gICAgXG4gICAgaWYgKGN1cnJlbnRTZXR0aW5ncy5hZ2dyZXNzaW9uTGV2ZWwgPT09ICdsb3cnKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCfwn5SNIEFHR1JFU1NJT04gREVCVUc6IExvdyBhZ2dyZXNzaW9uIC0gbm8gYWRkaXRpb25hbCBhY3Rpb25zJyk7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgXG4gICAgaWYgKGN1cnJlbnRTZXR0aW5ncy5hZ2dyZXNzaW9uTGV2ZWwgPT09ICdoaWdoJykge1xuICAgICAgICBjb25zb2xlLmxvZygn8J+UjSBBR0dSRVNTSU9OIERFQlVHOiBIaWdoIGFnZ3Jlc3Npb24gLSBtaW5pbWl6aW5nIGNvbW1lbnQnKTtcbiAgICAgICAgY29uc3QgbWluaW1pemVkID0gbWluaW1pemVDb21tZW50KGNvbW1lbnRFbGVtZW50KTtcbiAgICAgICAgaWYgKG1pbmltaXplZCkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ+KchSBBR0dSRVNTSU9OIFNVQ0NFU1M6IEF1dG8tbWluaW1pemVkIEFJIGNvbW1lbnQgZHVlIHRvIGhpZ2ggYWdncmVzc2lvbiBsZXZlbCcpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ+KdjCBBR0dSRVNTSU9OIEZBSUxFRDogQ291bGQgbm90IG1pbmltaXplIEFJIGNvbW1lbnQnKTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLy8gRnVuY3Rpb24gdG8gZXh0cmFjdCB1c2VybmFtZSBmcm9tIGNvbW1lbnQgZWxlbWVudFxuZnVuY3Rpb24gZXh0cmFjdFVzZXJuYW1lKGNvbW1lbnRFbGVtZW50KSB7XG4gICAgLy8gVHJ5IG11bHRpcGxlIHN0cmF0ZWdpZXMgdG8gZmluZCB0aGUgdXNlcm5hbWUsIGJlaW5nIHZlcnkgc3BlY2lmaWMgdG8gYXZvaWQgcHJvZmlsZSBwYWdlIGNvbmZ1c2lvblxuICAgIGNvbnN0IGNvbnRhaW5lciA9IGNvbW1lbnRFbGVtZW50LmNsb3Nlc3QoJ3NocmVkZGl0LXByb2ZpbGUtY29tbWVudCwgc2hyZWRkaXQtY29tbWVudCwgW2RhdGEtdGVzdGlkPVwiY29tbWVudFwiXSwgLmNvbW1lbnQnKTtcbiAgICBpZiAoIWNvbnRhaW5lcikgcmV0dXJuIG51bGw7XG4gICAgXG4gICAgLy8gU3RyYXRlZ3kgMTogTmV3IFJlZGRpdCBwcm9maWxlIGNvbW1lbnRzIC0gbG9vayBmb3IgYXV0aG9yIG5hbWUgaW4gdGhlIGNvbW1lbnQgaGVhZGVyXG4gICAgaWYgKGNvbnRhaW5lci50YWdOYW1lID09PSAnU0hSRURESVQtUFJPRklMRS1DT01NRU5UJykge1xuICAgICAgICAvLyBMb29rIGZvciB0aGUgYXV0aG9yIG5hbWUgc3BlY2lmaWNhbGx5IHdpdGhpbiB0aGlzIGNvbW1lbnQncyBtZXRhZGF0YVxuICAgICAgICBjb25zdCBhdXRob3JMaW5rID0gY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJ2FbaHJlZio9XCIvdXNlci9cIl0sIGFbaHJlZio9XCIvdS9cIl0nKTtcbiAgICAgICAgaWYgKGF1dGhvckxpbmspIHtcbiAgICAgICAgICAgIGNvbnN0IGhyZWYgPSBhdXRob3JMaW5rLmdldEF0dHJpYnV0ZSgnaHJlZicpO1xuICAgICAgICAgICAgY29uc3QgdXNlcm5hbWUgPSBocmVmLm1hdGNoKC9cXC91KD86c2VyKT9cXC8oW15cXC9cXD9cXCNdKykvKT8uWzFdO1xuICAgICAgICAgICAgaWYgKHVzZXJuYW1lICYmIHVzZXJuYW1lICE9PSAnW2RlbGV0ZWRdJykgcmV0dXJuIHVzZXJuYW1lO1xuICAgICAgICB9XG4gICAgfVxuICAgIFxuICAgIC8vIFN0cmF0ZWd5IDI6IE9sZCBSZWRkaXQgLSBsb29rIGZvciAuYXV0aG9yIGNsYXNzIGJ1dCBlbnN1cmUgaXQncyB3aXRoaW4gdGhlIGNvbW1lbnQncyB0YWdsaW5lLCBub3QgdGhlIHBhcmVudCBwb3N0XG4gICAgY29uc3QgYXV0aG9yRWwgPSBjb250YWluZXIucXVlcnlTZWxlY3RvcignLnRhZ2xpbmUgLmF1dGhvcicpO1xuICAgIGlmIChhdXRob3JFbCkge1xuICAgICAgICBjb25zdCB0ZXh0ID0gYXV0aG9yRWwudGV4dENvbnRlbnQ/LnRyaW0oKTtcbiAgICAgICAgaWYgKHRleHQgJiYgdGV4dCAhPT0gJ1tkZWxldGVkXScgJiYgIXRleHQuaW5jbHVkZXMoJyAnKSAmJiB0ZXh0Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHJldHVybiB0ZXh0O1xuICAgICAgICB9XG4gICAgfVxuICAgIFxuICAgIC8vIFN0cmF0ZWd5IDM6IE5ldyBSZWRkaXQgLSBsb29rIGZvciBhdXRob3ItbmFtZSBhdHRyaWJ1dGUgb24gZWxlbWVudHMgd2l0aGluIHRoZSBjb21tZW50XG4gICAgY29uc3QgYXV0aG9yTmFtZUVsID0gY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3IoJ1thdXRob3ItbmFtZV0nKTtcbiAgICBpZiAoYXV0aG9yTmFtZUVsKSB7XG4gICAgICAgIGNvbnN0IGF1dGhvck5hbWUgPSBhdXRob3JOYW1lRWwuZ2V0QXR0cmlidXRlKCdhdXRob3ItbmFtZScpO1xuICAgICAgICBpZiAoYXV0aG9yTmFtZSAmJiBhdXRob3JOYW1lICE9PSAnW2RlbGV0ZWRdJykgcmV0dXJuIGF1dGhvck5hbWU7XG4gICAgfVxuICAgIFxuICAgIC8vIFN0cmF0ZWd5IDQ6IExvb2sgZm9yIHVzZXJuYW1lIGxpbmtzIGJ1dCBwcmlvcml0aXplIG9uZXMgaW4gY29tbWVudCBtZXRhZGF0YSwgbm90IHBvc3QgdGl0bGVzXG4gICAgY29uc3QgdXNlckxpbmtzID0gY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoJ2FbaHJlZio9XCIvdXNlci9cIl0sIGFbaHJlZio9XCIvdS9cIl0nKTtcbiAgICBmb3IgKGNvbnN0IGxpbmsgb2YgdXNlckxpbmtzKSB7XG4gICAgICAgIC8vIFNraXAgbGlua3MgdGhhdCBhcmUgaW4gcG9zdCB0aXRsZXMgb3Igb3RoZXIgY29udGVudFxuICAgICAgICBjb25zdCBsaW5rVGV4dCA9IGxpbmsudGV4dENvbnRlbnQ/LnRyaW0oKTtcbiAgICAgICAgY29uc3QgaHJlZiA9IGxpbmsuZ2V0QXR0cmlidXRlKCdocmVmJyk7XG4gICAgICAgIGNvbnN0IHVzZXJuYW1lID0gaHJlZi5tYXRjaCgvXFwvdSg/OnNlcik/XFwvKFteXFwvXFw/XFwjXSspLyk/LlsxXTtcbiAgICAgICAgXG4gICAgICAgIC8vIENoZWNrIGlmIHRoaXMgbGluayBpcyBsaWtlbHkgdGhlIGNvbW1lbnQgYXV0aG9yIChub3QgaW4gcG9zdCBjb250ZW50KVxuICAgICAgICBjb25zdCBpc0luQ29tbWVudE1ldGEgPSBsaW5rLmNsb3Nlc3QoJy50YWdsaW5lLCBbaWQqPVwicG9zdGVyLWluZm9cIl0sIC5jb21tZW50LW1ldGEsIGZhY2VwbGF0ZS1ob3ZlcmNhcmQnKTtcbiAgICAgICAgaWYgKHVzZXJuYW1lICYmIHVzZXJuYW1lICE9PSAnW2RlbGV0ZWRdJyAmJiAoaXNJbkNvbW1lbnRNZXRhIHx8IGxpbmtUZXh0ID09PSB1c2VybmFtZSkpIHtcbiAgICAgICAgICAgIHJldHVybiB1c2VybmFtZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBcbiAgICAvLyBTdHJhdGVneSA1OiBMb29rIGZvciBkYXRhLWF1dGhvciBhdHRyaWJ1dGVcbiAgICBjb25zdCBkYXRhQXV0aG9yRWwgPSBjb250YWluZXIucXVlcnlTZWxlY3RvcignW2RhdGEtYXV0aG9yXScpO1xuICAgIGlmIChkYXRhQXV0aG9yRWwpIHtcbiAgICAgICAgY29uc3QgYXV0aG9yID0gZGF0YUF1dGhvckVsLmdldEF0dHJpYnV0ZSgnZGF0YS1hdXRob3InKTtcbiAgICAgICAgaWYgKGF1dGhvciAmJiBhdXRob3IgIT09ICdbZGVsZXRlZF0nKSByZXR1cm4gYXV0aG9yO1xuICAgIH1cbiAgICBcbiAgICAvLyBTdHJhdGVneSA2OiBOZXcgUmVkZGl0IHNwZWNpZmljIC0gbG9vayBmb3IgcG9zdGVyIGluZm8gd2l0aGluIHRoZSBjb21tZW50XG4gICAgY29uc3QgcG9zdGVySW5mbyA9IGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yKCdbaWQqPVwicG9zdGVyLWluZm9cIl0nKTtcbiAgICBpZiAocG9zdGVySW5mbykge1xuICAgICAgICBjb25zdCB1c2VyTGluayA9IHBvc3RlckluZm8ucXVlcnlTZWxlY3RvcignYVtocmVmKj1cIi91c2VyL1wiXSwgYVtocmVmKj1cIi91L1wiXScpO1xuICAgICAgICBpZiAodXNlckxpbmspIHtcbiAgICAgICAgICAgIGNvbnN0IGhyZWYgPSB1c2VyTGluay5nZXRBdHRyaWJ1dGUoJ2hyZWYnKTtcbiAgICAgICAgICAgIGNvbnN0IHVzZXJuYW1lID0gaHJlZi5tYXRjaCgvXFwvdSg/OnNlcik/XFwvKFteXFwvXFw/XFwjXSspLyk/LlsxXTtcbiAgICAgICAgICAgIGlmICh1c2VybmFtZSAmJiB1c2VybmFtZSAhPT0gJ1tkZWxldGVkXScpIHJldHVybiB1c2VybmFtZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBcbiAgICBjb25zb2xlLmxvZygnQ291bGQgbm90IGV4dHJhY3QgdXNlcm5hbWUgZnJvbSBjb21tZW50OicsIGNvbnRhaW5lcik7XG4gICAgcmV0dXJuIG51bGw7XG59XG5cbi8vIEZ1bmN0aW9uIHRvIHByb2Nlc3MgYSBzaW5nbGUgY29tbWVudFxuYXN5bmMgZnVuY3Rpb24gcHJvY2Vzc0NvbW1lbnQoY29tbWVudEVsZW1lbnQsIGluZGV4ID0gMCkge1xuICAgIC8vIEdldCBhIG1vcmUgcmVsaWFibGUgY29tbWVudCBJRCBmb3IgcHJvZmlsZSBwYWdlc1xuICAgIGNvbnN0IGNvbnRhaW5lciA9IGNvbW1lbnRFbGVtZW50LmNsb3Nlc3QoJ3NocmVkZGl0LXByb2ZpbGUtY29tbWVudCwgc2hyZWRkaXQtY29tbWVudCwgW2RhdGEtdGVzdGlkPVwiY29tbWVudFwiXSwgLmNvbW1lbnQnKTtcbiAgICBsZXQgY29tbWVudElkID0gbnVsbDtcbiAgICBcbiAgICAvLyBUcnkgbXVsdGlwbGUgc3RyYXRlZ2llcyB0byBnZXQgYSB1bmlxdWUgY29tbWVudCBJRFxuICAgIGlmIChjb250YWluZXIpIHtcbiAgICAgICAgY29tbWVudElkID0gY29udGFpbmVyLmdldEF0dHJpYnV0ZSgnY29tbWVudC1pZCcpIHx8XG4gICAgICAgICAgICAgICAgICAgY29udGFpbmVyLmdldEF0dHJpYnV0ZSgnZGF0YS1jb21tZW50LWlkJykgfHxcbiAgICAgICAgICAgICAgICAgICBjb250YWluZXIuZ2V0QXR0cmlidXRlKCdkYXRhLXRlc3RpZCcpIHx8XG4gICAgICAgICAgICAgICAgICAgY29udGFpbmVyLmlkO1xuICAgIH1cbiAgICBcbiAgICAvLyBGYWxsYmFjayB0byBlbGVtZW50IGF0dHJpYnV0ZXNcbiAgICBpZiAoIWNvbW1lbnRJZCkge1xuICAgICAgICBjb21tZW50SWQgPSBjb21tZW50RWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2RhdGEtY29tbWVudC1pZCcpIHx8IFxuICAgICAgICAgICAgICAgICAgIGNvbW1lbnRFbGVtZW50LmdldEF0dHJpYnV0ZSgnZGF0YS10ZXN0aWQnKSB8fCBcbiAgICAgICAgICAgICAgICAgICBjb21tZW50RWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2lkJyk7XG4gICAgfVxuICAgIFxuICAgIC8vIExhc3QgcmVzb3J0OiB1c2UgYSBoYXNoIG9mIHRoZSBjb21tZW50IGNvbnRlbnRcbiAgICBpZiAoIWNvbW1lbnRJZCkge1xuICAgICAgICBjb25zdCB0ZXh0ID0gZ2V0Q29tbWVudFRleHQoY29tbWVudEVsZW1lbnQpO1xuICAgICAgICBjb21tZW50SWQgPSBgY29tbWVudF8ke3RleHQuc3Vic3RyaW5nKDAsIDUwKS5yZXBsYWNlKC9cXHMrL2csICdfJyl9YDtcbiAgICB9XG4gICAgXG4gICAgaWYgKHByb2Nlc3NlZENvbW1lbnRzLmhhcyhjb21tZW50SWQpKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdTa2lwcGluZyBhbHJlYWR5IHByb2Nlc3NlZCBjb21tZW50Jyk7XG4gICAgICAgIHByb2Nlc3NlZENvdW50Kys7XG4gICAgICAgIHVwZGF0ZVByb2dyZXNzKHByb2Nlc3NlZENvdW50LCB0b3RhbENvbW1lbnRzLCAnU2tpcHBpbmcgZHVwbGljYXRlIGNvbW1lbnQnKTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBwcm9jZXNzZWRDb21tZW50cy5hZGQoY29tbWVudElkKTtcbiAgICBcbiAgICAvLyBFeHRyYWN0IHVzZXJuYW1lXG4gICAgY29uc3QgdXNlcm5hbWUgPSBleHRyYWN0VXNlcm5hbWUoY29tbWVudEVsZW1lbnQpO1xuICAgIFxuICAgIC8vIENoZWNrIGlmIHdlJ3ZlIGFscmVhZHkgcHJvY2Vzc2VkIHRoaXMgY29tbWVudCBmb3IgdGhpcyB1c2VyXG4gICAgaWYgKHVzZXJuYW1lICYmIHVzZXJTY29yZU1hbmFnZXIuaXNDb21tZW50UHJvY2Vzc2VkKHVzZXJuYW1lLCBjb21tZW50SWQpKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBDb21tZW50ICR7Y29tbWVudElkfSBhbHJlYWR5IHByb2Nlc3NlZCBmb3IgdXNlciAke3VzZXJuYW1lfSwgdXNpbmcgY2FjaGVkIHJlc3VsdGApO1xuICAgICAgICBjb25zdCBjYWNoZWRSZXN1bHQgPSB1c2VyU2NvcmVNYW5hZ2VyLmdldENhY2hlZENvbW1lbnRSZXN1bHQodXNlcm5hbWUsIGNvbW1lbnRJZCk7XG4gICAgICAgIFxuICAgICAgICAvLyBBcHBseSB0aGUgdmlzdWFsIGluZGljYXRvcnMgYmFzZWQgb24gY2FjaGVkIHJlc3VsdFxuICAgICAgICBpZiAoY2FjaGVkUmVzdWx0LmlzQUkpIHtcbiAgICAgICAgICAgIGhpZ2hsaWdodExMTUNvbW1lbnQoY29tbWVudEVsZW1lbnQpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICAvLyBBcHBseSBhZ2dyZXNzaW9uLWJhc2VkIGFjdGlvbnMgZm9yIGNhY2hlZCBBSSBjb21tZW50cyB0b29cbiAgICAgICAgICAgIGFwcGx5QWdncmVzc2lvbkFjdGlvbnMoY29tbWVudEVsZW1lbnQpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICB1cGRhdGVQcm9ncmVzcyhwcm9jZXNzZWRDb3VudCArIDEsIHRvdGFsQ29tbWVudHMsIGDimqDvuI8gQ2FjaGVkIEFJIGNvbW1lbnQgKCR7TWF0aC5yb3VuZChjYWNoZWRSZXN1bHQuY29uZmlkZW5jZSAqIDEwMCl9JSBjb25maWRlbmNlKWApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbWFya0h1bWFuQ29tbWVudChjb21tZW50RWxlbWVudCk7XG4gICAgICAgICAgICB1cGRhdGVQcm9ncmVzcyhwcm9jZXNzZWRDb3VudCArIDEsIHRvdGFsQ29tbWVudHMsIGBDYWNoZWQgaHVtYW4gY29tbWVudGApO1xuICAgICAgICB9XG4gICAgICAgIFxuICAgICAgICBwcm9jZXNzZWRDb3VudCsrO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIFxuICAgIGNvbnN0IHRleHQgPSBnZXRDb21tZW50VGV4dChjb21tZW50RWxlbWVudCk7XG4gICAgY29uc29sZS5sb2coYFByb2Nlc3NpbmcgY29tbWVudCAoJHt0ZXh0Lmxlbmd0aH0gY2hhcnMpOiBcIiR7dGV4dC5zdWJzdHJpbmcoMCwgMTAwKX0uLi5cImApO1xuICAgIFxuICAgIHVwZGF0ZVByb2dyZXNzKHByb2Nlc3NlZENvdW50LCB0b3RhbENvbW1lbnRzLCBgUHJvY2Vzc2luZyBjb21tZW50ICR7cHJvY2Vzc2VkQ291bnQgKyAxfS4uLmApO1xuICAgIFxuICAgIGlmICghdGV4dCkge1xuICAgICAgICBjb25zb2xlLmxvZygnU2tpcHBpbmcgY29tbWVudCAtIG5vIHRleHQgY29udGVudCcpO1xuICAgICAgICBwcm9jZXNzZWRDb3VudCsrO1xuICAgICAgICB1cGRhdGVQcm9ncmVzcyhwcm9jZXNzZWRDb3VudCwgdG90YWxDb21tZW50cywgJ1NraXBwaW5nIGVtcHR5IGNvbW1lbnQnKTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBcbiAgICBpZiAodGV4dC5sZW5ndGggPCAxMCkge1xuICAgICAgICBjb25zb2xlLmxvZygnU2tpcHBpbmcgY29tbWVudCAtIHRvbyBzaG9ydCcpO1xuICAgICAgICBwcm9jZXNzZWRDb3VudCsrO1xuICAgICAgICB1cGRhdGVQcm9ncmVzcyhwcm9jZXNzZWRDb3VudCwgdG90YWxDb21tZW50cywgJ1NraXBwaW5nIHNob3J0IGNvbW1lbnQnKTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBcbiAgICBjb25zb2xlLmxvZygnU2VuZGluZyBjb21tZW50IGZvciBjbGFzc2lmaWNhdGlvbi4uLicpO1xuICAgIHVwZGF0ZVByb2dyZXNzKHByb2Nlc3NlZENvdW50LCB0b3RhbENvbW1lbnRzLCBgQW5hbHl6aW5nIGNvbW1lbnQgJHtwcm9jZXNzZWRDb3VudCArIDF9Li4uYCk7XG4gICAgXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY2xhc3NpZnlDb21tZW50KHRleHQpO1xuICAgIFxuICAgIHByb2Nlc3NlZENvdW50Kys7XG4gICAgXG4gICAgaWYgKCFyZXN1bHQpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ0NsYXNzaWZpY2F0aW9uIGZhaWxlZCBvciByZXR1cm5lZCBudWxsJyk7XG4gICAgICAgIHVwZGF0ZVByb2dyZXNzKHByb2Nlc3NlZENvdW50LCB0b3RhbENvbW1lbnRzLCAnQ2xhc3NpZmljYXRpb24gZmFpbGVkJyk7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgXG4gICAgY29uc29sZS5sb2coJ0NsYXNzaWZpY2F0aW9uIHJlc3VsdDonLCByZXN1bHQpO1xuICAgIFxuICAgIC8vIENoZWNrIGlmIHRoZSBoaWdoZXN0IGNvbmZpZGVuY2UgcHJlZGljdGlvbiBpcyAnbGxtJ1xuICAgIGNvbnN0IHRvcFByZWRpY3Rpb24gPSBBcnJheS5pc0FycmF5KHJlc3VsdCkgPyByZXN1bHRbMF0gOiByZXN1bHQ7XG4gICAgY29uc29sZS5sb2coJ1RvcCBwcmVkaWN0aW9uOicsIHRvcFByZWRpY3Rpb24pO1xuICAgIFxuICAgIGlmICh0b3BQcmVkaWN0aW9uICYmIHRvcFByZWRpY3Rpb24ubGFiZWwgPT09ICdsbG0nKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBMTE0gZGV0ZWN0ZWQgd2l0aCBjb25maWRlbmNlOiAke3RvcFByZWRpY3Rpb24uc2NvcmV9YCk7XG4gICAgICAgIGlmICh0b3BQcmVkaWN0aW9uLnNjb3JlID4gMC41KSB7XG4gICAgICAgICAgICBoaWdobGlnaHRMTE1Db21tZW50KGNvbW1lbnRFbGVtZW50KTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLy8gQXBwbHkgYWdncmVzc2lvbi1iYXNlZCBhY3Rpb25zIChtaW5pbWl6ZS9kb3dudm90ZSlcbiAgICAgICAgICAgIGFwcGx5QWdncmVzc2lvbkFjdGlvbnMoY29tbWVudEVsZW1lbnQpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICAvLyBVcGRhdGUgdXNlciBzY29yZSBmb3IgQUkgY29tbWVudFxuICAgICAgICAgICAgaWYgKHVzZXJuYW1lKSB7XG4gICAgICAgICAgICAgICAgdXNlclNjb3JlTWFuYWdlci51cGRhdGVVc2VyU2NvcmUodXNlcm5hbWUsIGNvbW1lbnRJZCwgdHJ1ZSwgdG9wUHJlZGljdGlvbi5zY29yZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zb2xlLmxvZygn8J+aqCBMTE0gY29tbWVudCBoaWdobGlnaHRlZDonLCB0ZXh0LnN1YnN0cmluZygwLCAxMDApICsgJy4uLicsIHRvcFByZWRpY3Rpb24pO1xuICAgICAgICAgICAgdXBkYXRlUHJvZ3Jlc3MocHJvY2Vzc2VkQ291bnQsIHRvdGFsQ29tbWVudHMsIGDimqDvuI8gUG9zc2libGUgQUkgY29tbWVudCAoJHtNYXRoLnJvdW5kKHRvcFByZWRpY3Rpb24uc2NvcmUgKiAxMDApfSUgY29uZmlkZW5jZSlgKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdMTE0gY29uZmlkZW5jZSB0b28gbG93LCBub3QgaGlnaGxpZ2h0aW5nJyk7XG4gICAgICAgICAgICBtYXJrSHVtYW5Db21tZW50KGNvbW1lbnRFbGVtZW50KTtcbiAgICAgICAgICAgIC8vIFVwZGF0ZSB1c2VyIHNjb3JlIGZvciBodW1hbiBjb21tZW50XG4gICAgICAgICAgICBpZiAodXNlcm5hbWUpIHtcbiAgICAgICAgICAgICAgICB1c2VyU2NvcmVNYW5hZ2VyLnVwZGF0ZVVzZXJTY29yZSh1c2VybmFtZSwgY29tbWVudElkLCBmYWxzZSwgdG9wUHJlZGljdGlvbi5zY29yZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB1cGRhdGVQcm9ncmVzcyhwcm9jZXNzZWRDb3VudCwgdG90YWxDb21tZW50cywgYEh1bWFuIGNvbW1lbnQgKGxvdyBBSSBjb25maWRlbmNlKWApO1xuICAgICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coYEh1bWFuIGNvbW1lbnQgZGV0ZWN0ZWQ6ICR7dG9wUHJlZGljdGlvbj8ubGFiZWx9ICgke3RvcFByZWRpY3Rpb24/LnNjb3JlfSlgKTtcbiAgICAgICAgbWFya0h1bWFuQ29tbWVudChjb21tZW50RWxlbWVudCk7XG4gICAgICAgIC8vIFVwZGF0ZSB1c2VyIHNjb3JlIGZvciBodW1hbiBjb21tZW50XG4gICAgICAgIGlmICh1c2VybmFtZSkge1xuICAgICAgICAgICAgdXNlclNjb3JlTWFuYWdlci51cGRhdGVVc2VyU2NvcmUodXNlcm5hbWUsIGNvbW1lbnRJZCwgZmFsc2UsIHRvcFByZWRpY3Rpb24/LnNjb3JlIHx8IDAuNSk7XG4gICAgICAgIH1cbiAgICAgICAgdXBkYXRlUHJvZ3Jlc3MocHJvY2Vzc2VkQ291bnQsIHRvdGFsQ29tbWVudHMsIGBIdW1hbiBjb21tZW50IGRldGVjdGVkYCk7XG4gICAgfVxufVxuXG4vLyBGdW5jdGlvbiB0byBmaW5kIGFuZCBwcm9jZXNzIGFsbCBjb21tZW50c1xuYXN5bmMgZnVuY3Rpb24gcHJvY2Vzc0FsbENvbW1lbnRzKCkge1xuICAgIGNvbnNvbGUubG9nKCdTdGFydGluZyB0byBwcm9jZXNzIGFsbCBjb21tZW50cy4uLicpO1xuICAgIFxuICAgIC8vIFJlc2V0IHByb2dyZXNzIHRyYWNraW5nXG4gICAgcHJvY2Vzc2VkQ291bnQgPSAwO1xuICAgIHRvdGFsQ29tbWVudHMgPSAwO1xuICAgIFxuICAgIC8vIENyZWF0ZSBwcm9ncmVzcyB3aWRnZXRcbiAgICBpZiAocHJvZ3Jlc3NXaWRnZXQpIHtcbiAgICAgICAgcHJvZ3Jlc3NXaWRnZXQucmVtb3ZlKCk7XG4gICAgfVxuICAgIHByb2dyZXNzV2lkZ2V0ID0gY3JlYXRlUHJvZ3Jlc3NXaWRnZXQoKTtcbiAgICBcbiAgICAvLyBFbnN1cmUgbW9kZWwgaXMgcmVhZHkgYmVmb3JlIHByb2Nlc3NpbmdcbiAgICB1cGRhdGVQcm9ncmVzcygwLCAwLCAnTG9hZGluZyBBSSBtb2RlbC4uLicpO1xuICAgIGNvbnN0IG1vZGVsUmVhZHkgPSBhd2FpdCBlbnN1cmVNb2RlbFJlYWR5KCk7XG4gICAgaWYgKCFtb2RlbFJlYWR5KSB7XG4gICAgICAgIHVwZGF0ZVByb2dyZXNzKDAsIDAsICdGYWlsZWQgdG8gbG9hZCBBSSBtb2RlbCcpO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIGlmIChwcm9ncmVzc1dpZGdldCAmJiBwcm9ncmVzc1dpZGdldC5wYXJlbnROb2RlKSB7XG4gICAgICAgICAgICAgICAgcHJvZ3Jlc3NXaWRnZXQucmVtb3ZlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sIDMwMDApO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIFxuICAgIGNvbnN0IHZhcmlhbnQgPSBkZXRlY3RSZWRkaXRWYXJpYW50KCk7XG4gICAgY29uc29sZS5sb2coYERldGVjdGVkIFJlZGRpdCB2YXJpYW50OiAke3ZhcmlhbnR9YCk7XG4gICAgY29uc3Qgc2VsZWN0b3JzID0gUkVERElUX1NFTEVDVE9SU1t2YXJpYW50XTtcbiAgICBcbiAgICAvLyBUcnkgbXVsdGlwbGUgc2VsZWN0b3Igc3RyYXRlZ2llc1xuICAgIGNvbnN0IHNlbGVjdG9yU2V0cyA9IFtzZWxlY3RvcnMsIFJFRERJVF9TRUxFQ1RPUlMuZ2VuZXJhbF07XG4gICAgXG4gICAgZm9yIChjb25zdCBzZWxlY3RvclNldCBvZiBzZWxlY3RvclNldHMpIHtcbiAgICAgICAgY29uc29sZS5sb2coYFRyeWluZyBzZWxlY3RvcjogJHtzZWxlY3RvclNldC5jb21tZW50c31gKTtcbiAgICAgICAgY29uc3QgY29tbWVudHMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9yU2V0LmNvbW1lbnRzKTtcbiAgICAgICAgY29uc29sZS5sb2coYEZvdW5kICR7Y29tbWVudHMubGVuZ3RofSBjb21tZW50cyB3aXRoIHRoaXMgc2VsZWN0b3JgKTtcbiAgICAgICAgXG4gICAgICAgIGlmIChjb21tZW50cy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhg4pyFIEZvdW5kICR7Y29tbWVudHMubGVuZ3RofSBjb21tZW50cyB1c2luZyAke3ZhcmlhbnR9IHNlbGVjdG9yc2ApO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICAvLyBQcm9jZXNzIGFsbCBjb21tZW50cyBmb3VuZFxuICAgICAgICAgICAgdG90YWxDb21tZW50cyA9IGNvbW1lbnRzLmxlbmd0aDtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBQcm9jZXNzaW5nIGFsbCAke3RvdGFsQ29tbWVudHN9IGNvbW1lbnRzLi4uYCk7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHVwZGF0ZVByb2dyZXNzKDAsIHRvdGFsQ29tbWVudHMsICdTdGFydGluZyBhbmFseXNpcy4uLicpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRvdGFsQ29tbWVudHM7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBQcm9jZXNzaW5nIGNvbW1lbnQgJHtpICsgMX0vJHt0b3RhbENvbW1lbnRzfWApO1xuICAgICAgICAgICAgICAgIHByb2Nlc3NDb21tZW50KGNvbW1lbnRzW2ldLCBpKTsgLy8gTm8gZGVsYXkgYmV0d2VlbiBjb21tZW50c1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICB9XG4gICAgXG4gICAgaWYgKHRvdGFsQ29tbWVudHMgPT09IDApIHtcbiAgICAgICAgdXBkYXRlUHJvZ3Jlc3MoMCwgMCwgJ05vIGNvbW1lbnRzIGZvdW5kIHRvIGFuYWx5emUnKTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICBpZiAocHJvZ3Jlc3NXaWRnZXQgJiYgcHJvZ3Jlc3NXaWRnZXQucGFyZW50Tm9kZSkge1xuICAgICAgICAgICAgICAgIHByb2dyZXNzV2lkZ2V0LnJlbW92ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LCAzMDAwKTtcbiAgICB9XG4gICAgXG4gICAgLy8gVXBkYXRlIGV4aXN0aW5nIHVzZXIgZGlzcGxheXNcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdXNlclNjb3JlTWFuYWdlci51cGRhdGVBbGxVc2VyRGlzcGxheXMoKTtcbiAgICB9LCAyMDAwKTtcbiAgICBcbiAgICBjb25zb2xlLmxvZygnRmluaXNoZWQgcXVldWVpbmcgY29tbWVudHMgZm9yIHByb2Nlc3NpbmcnKTtcbn1cblxuLy8gSW5pdGlhbCBwcm9jZXNzaW5nIC0gc3RhcnQgaW1tZWRpYXRlbHkgc2luY2Ugd2Ugbm93IGNoZWNrIG1vZGVsIHJlYWRpbmVzc1xuc2V0VGltZW91dCgoKSA9PiB7XG4gICAgaWYgKGN1cnJlbnRTZXR0aW5ncy5hdXRvQW5hbHl6ZSkge1xuICAgICAgICBwcm9jZXNzQWxsQ29tbWVudHMoKTtcbiAgICB9XG59LCAxMDAwKTtcblxuLy8gVXBkYXRlIHVzZXIgZGlzcGxheXMgb24gcGFnZSBsb2FkXG5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICB1c2VyU2NvcmVNYW5hZ2VyLnVwZGF0ZUFsbFVzZXJEaXNwbGF5cygpO1xufSwgMjAwMCk7XG5cbi8vIFdhdGNoIGZvciBkeW5hbWljYWxseSBsb2FkZWQgY29udGVudFxuY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcigobXV0YXRpb25zKSA9PiB7XG4gICAgbGV0IHNob3VsZFByb2Nlc3MgPSBmYWxzZTtcbiAgICBcbiAgICBtdXRhdGlvbnMuZm9yRWFjaCgobXV0YXRpb24pID0+IHtcbiAgICAgICAgaWYgKG11dGF0aW9uLnR5cGUgPT09ICdjaGlsZExpc3QnICYmIG11dGF0aW9uLmFkZGVkTm9kZXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgLy8gQ2hlY2sgaWYgbmV3IG5vZGVzIGNvbnRhaW4gY29tbWVudHNcbiAgICAgICAgICAgIG11dGF0aW9uLmFkZGVkTm9kZXMuZm9yRWFjaCgobm9kZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChub2RlLm5vZGVUeXBlID09PSBOb2RlLkVMRU1FTlRfTk9ERSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB2YXJpYW50ID0gZGV0ZWN0UmVkZGl0VmFyaWFudCgpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBzZWxlY3RvcnMgPSBSRURESVRfU0VMRUNUT1JTW3ZhcmlhbnRdO1xuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgaWYgKG5vZGUubWF0Y2hlcyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICBub2RlLm1hdGNoZXMoc2VsZWN0b3JzLmNvbW1lbnRzKSB8fCBcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vZGUubWF0Y2hlcyhzZWxlY3RvcnMuY29tbWVudENvbnRhaW5lcikgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vZGUucXVlcnlTZWxlY3RvcihzZWxlY3RvcnMuY29tbWVudHMpXG4gICAgICAgICAgICAgICAgICAgICkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3VsZFByb2Nlc3MgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICBcbiAgICBpZiAoc2hvdWxkUHJvY2Vzcykge1xuICAgICAgICBpZiAoY3VycmVudFNldHRpbmdzLmF1dG9BbmFseXplKSB7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KHByb2Nlc3NBbGxDb21tZW50cywgNTAwKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBBbHNvIHVwZGF0ZSB1c2VyIGRpc3BsYXlzIHdoZW4gbmV3IGNvbnRlbnQgbG9hZHNcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICB1c2VyU2NvcmVNYW5hZ2VyLnVwZGF0ZUFsbFVzZXJEaXNwbGF5cygpO1xuICAgICAgICB9LCAxMDAwKTtcbiAgICB9XG59KTtcblxuLy8gU3RhcnQgb2JzZXJ2aW5nXG5vYnNlcnZlci5vYnNlcnZlKGRvY3VtZW50LmJvZHksIHtcbiAgICBjaGlsZExpc3Q6IHRydWUsXG4gICAgc3VidHJlZTogdHJ1ZVxufSk7XG5cbi8vIEFsc28gcHJvY2VzcyB3aGVuIHBhZ2UgbmF2aWdhdGlvbiBvY2N1cnMgKGZvciBTUEEgYmVoYXZpb3IpXG5sZXQgY3VycmVudFVybCA9IHdpbmRvdy5sb2NhdGlvbi5ocmVmO1xuc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgIGlmICh3aW5kb3cubG9jYXRpb24uaHJlZiAhPT0gY3VycmVudFVybCkge1xuICAgICAgICBjdXJyZW50VXJsID0gd2luZG93LmxvY2F0aW9uLmhyZWY7XG4gICAgICAgIHByb2Nlc3NlZENvbW1lbnRzLmNsZWFyKCk7XG4gICAgICAgIGlmIChjdXJyZW50U2V0dGluZ3MuYXV0b0FuYWx5emUpIHtcbiAgICAgICAgICAgIHNldFRpbWVvdXQocHJvY2Vzc0FsbENvbW1lbnRzLCAyMDAwKTtcbiAgICAgICAgfVxuICAgIH1cbn0sIDEwMDApO1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9